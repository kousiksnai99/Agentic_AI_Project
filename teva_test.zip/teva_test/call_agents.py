from config import (
    project_client,
    CLASSIFICATION_AGENT_ID,
    TROUBLESHOOTING_AGENT_ID,
    TICKETING_AGENT_ID
)
from workflow_manager import AutoGenWorkflowManager
import uuid


CLASSIFICATION_AGENT_ID="asst_80rdCpXQLdOxKihVdvDiJWMJ"
TROUBLESHOOTING_AGENT_ID="asst_fPXYBH0F411IgQ3pNBWWQZhK"
TICKETING_AGENT_ID="asst_UoCXDWdtvjTlUuZ1bpYFlv76"    #"asst_6lk6fKNnDKsqLgNsYjMmKu8V"

def call_agents():
    user_input = input("Describe your Outlook issue: ")
    
    workflow = AutoGenWorkflowManager(
        project_client,
        classification_agent_id=CLASSIFICATION_AGENT_ID,
        troubleshooting_agent_id=TROUBLESHOOTING_AGENT_ID,
        ticketing_agent_id=TICKETING_AGENT_ID
    )
    
    # Create thread
    thread = project_client.agents.threads.create()
    thread_id = thread.id
    trace_id = str(uuid.uuid4())
    
    print(f"Thread ID: {thread_id}")
    print(f"Trace ID: {trace_id}")
    
    # Step 1: Classification
    print("\n=== CLASSIFICATION ===")
    workflow.add_task("classify_issue", f"Classify this Outlook issue: {user_input}")
    workflow.execute_task("classify_issue", thread_id)
    classification_result = workflow.results.get("classify_issue")
    
    if classification_result and "out of scope" not in str(classification_result).lower():
        # Step 2: Troubleshooting
        print("\n=== TROUBLESHOOTING ===")
        workflow.add_task("troubleshoot_issue", f"Provide PowerShell diagnostic script for: {classification_result}")
        workflow.execute_task("troubleshoot_issue", thread_id)
        troubleshooting_result = workflow.results.get("troubleshoot_issue")
        
        if troubleshooting_result:
            print("Troubleshooting script generated successfully!")
            
            # Ask user if issue is resolved
            user_satisfied = input("\nDid this solve your issue? (Y/N): ").strip().upper()
            
            if user_satisfied != 'Y':
                print("\n=== CREATING TICKET ===")
                workflow.add_task("ticketing", f"Create ticket for unresolved issue: {user_input}")
                workflow.execute_task("ticketing", thread_id)
            else:
                print("Issue resolved successfully!")
        else:
            print("\n=== CREATING TICKET ===")
            workflow.add_task("ticketing", f"Troubleshooting failed for: {user_input}")
            workflow.execute_task("ticketing", thread_id)
    else:
        print("\n=== CREATING TICKET ===")
        workflow.add_task("ticketing", f"Out of scope issue: {user_input}")
        workflow.execute_task("ticketing", thread_id)
    
    print("\n=== WORKFLOW COMPLETE ===")
    print("Final Results:")
    for task_id, result in workflow.results.items():
        print(f"{task_id}: {result}")

if __name__ == "__main__":
    call_agents()