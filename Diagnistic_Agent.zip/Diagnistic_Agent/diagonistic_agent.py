#!/usr/bin/env python3
"""
Azure AI Diagnostics Agent - Integrated with Azure Automation
Supports Outlook issue diagnostics + running PowerShell scripts via Automation Hybrid Worker
"""

import os
import sys
import time
import uuid
import logging
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential, ClientSecretCredential
from azure.ai.agents.models import ListSortOrder
from azure.core.exceptions import AzureError
from azure.mgmt.automation import AutomationClient
from azure.mgmt.automation.models import RunbookCreateOrUpdateParameters, JobCreateParameters

# =====================
# CONFIGURATION
# =====================
AZURE_CLIENT_ID = "81386a90-2812-40cc-af4e-17d369a4bce6"
AZURE_CLIENT_SECRET = "HwM8Q~U37PWQSvdzG_mtpaAjM0JTIlQnmQnXwdcP"
AZURE_TENANT_ID = "d43bb47a-1517-44e9-bed6-568710cc49d1"
AZURE_SUBSCRIPTION_ID = "5800483a-b5a1-46c6-b26d-33be8c3fe50f"
AZURE_RESOURCE_GROUP = "aoairg"
AUTOMATION_ACCOUNT = "azure-automation-test"
RUNBOOK_NAME = "kousik_runbook_test"
HYBRID_WORKER_GROUP = "azureautomationtestcentre"

# Azure AI Agent
PROJECT_ENDPOINT = "https://classification-agent-resource.services.ai.azure.com/api/projects/classification-agent"
AGENT_ID = "asst_fPXYBH0F411IgQ3pNBWWQZhK"

# Script mapping
SCRIPT_MAPPING = {
    "create ost profile": "scripts/create_ost_profile.ps1",
    "start in safe mode": "scripts/start_safe_mode.ps1",
    "check if account is locked or password expired": "scripts/check_account_status.ps1",
    "clearing stored passwords from credential manager": "scripts/clear_stored_passwords.ps1",
    "disable work offline in outlook": "scripts/disable_work_offline.ps1"
}

# Reduce noisy logs
logging.getLogger("azure").setLevel(logging.ERROR)
logging.getLogger("msal").setLevel(logging.ERROR)


class DiagnosticsAgent:
    def __init__(self):
        load_dotenv()

        if not PROJECT_ENDPOINT or not AGENT_ID:
            raise ValueError("Missing PROJECT_ENDPOINT or AGENT_ID")

        # AI Project client
        try:
            self.credential = DefaultAzureCredential()
            self.project = AIProjectClient(
                credential=self.credential,
                endpoint=PROJECT_ENDPOINT
            )
        except Exception as e:
            raise Exception(f"Azure AI client init failed: {e}")

        # Automation client
        try:
            self.automation_credential = ClientSecretCredential(
                tenant_id=AZURE_TENANT_ID,
                client_id=AZURE_CLIENT_ID,
                client_secret=AZURE_CLIENT_SECRET
            )
            self.automation_client = AutomationClient(
                credential=self.automation_credential,
                subscription_id=AZURE_SUBSCRIPTION_ID
            )
        except Exception as e:
            raise Exception(f"Azure Automation client init failed: {e}")

        # Create chat thread
        self.thread = self.project.agents.threads.create()
        print(f"[DEBUG] Created thread: {self.thread.id}")

    # ------------------
    # Fetch only Output stream logs
    # ------------------
    def fetch_job_output(self, job_name: str) -> str:
        """Fetch only Output stream logs from Automation job."""
        output_lines = []
        for attempt in range(12):  # retry up to 1 min
            pager = self.automation_client.job_stream.list_by_job(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                job_name=job_name
            )
            for stream in pager:
                if getattr(stream, "stream_type", "").lower() == "output":
                    stext = getattr(stream, "stream_text", "")
                    if stext:
                        output_lines.append(stext.strip())

            if output_lines:
                break
            time.sleep(5)

        if not output_lines:
            return "⚠️ Runbook completed but no *Output* captured. (Ensure you use Write-Output in script)"

        return "\n".join(output_lines)

    # ------------------
    # Run PowerShell script via Automation
    # ------------------
    def run_script(self, problem_key: str) -> str:
        try:
            script_path = SCRIPT_MAPPING.get(problem_key.lower())
            if not script_path or not os.path.exists(script_path):
                return f"No script found for problem: {problem_key}"

            # Load script content
            with open(script_path, "r", encoding="utf-8") as f:
                script_content = f.read()

            # Ensure runbook exists
            self.automation_client.runbook.create_or_update(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                runbook_name=RUNBOOK_NAME,
                parameters=RunbookCreateOrUpdateParameters(
                    name=RUNBOOK_NAME,
                    location="eastus2",
                    log_verbose=True,
                    log_progress=True,
                    runbook_type="PowerShell",
                    description=f"Diagnostic runbook for {problem_key}"
                )
            )

            # Replace draft content
            poller = self.automation_client.runbook_draft.begin_replace_content(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                runbook_name=RUNBOOK_NAME,
                runbook_content=script_content
            )
            poller.result()

            # Publish runbook
            publish_poller = self.automation_client.runbook.begin_publish(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                runbook_name=RUNBOOK_NAME
            )
            publish_poller.result()

            # Generate unique job name
            job_name = f"{RUNBOOK_NAME}_job_{uuid.uuid4().hex[:8]}"

            # Create job
            job_params = JobCreateParameters(
                runbook={"name": RUNBOOK_NAME},
                run_on=HYBRID_WORKER_GROUP
            )
            job = self.automation_client.job.create(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                job_name=job_name,
                parameters=job_params
            )
            job_id = job.job_id
            print(f"[DEBUG] Started runbook job: {job_id}")

            # Poll until job completes
            while True:
                job_status = self.automation_client.job.get(
                    resource_group_name=AZURE_RESOURCE_GROUP,
                    automation_account_name=AUTOMATION_ACCOUNT,
                    job_name=job_name
                )
                state = job_status.status.lower()
                if state in ["completed", "failed", "stopped", "suspended"]:
                    print(f"[DEBUG] Runbook finished with status: {state}")
                    break
                time.sleep(5)

            # ✅ Only Output stream
            return self.fetch_job_output(job_name)

        except Exception as e:
            return f"Script execution error: {e}"

    # ------------------
    # Chat with agent
    # ------------------
    def chat(self, user_message: str) -> str:
        try:
            # If message matches one of the script problems → run script
            for problem in SCRIPT_MAPPING.keys():
                if problem in user_message.lower():
                    return self.run_script(problem)

            # Otherwise, normal AI flow
            agent = self.project.agents.get_agent(AGENT_ID)
            self.project.agents.messages.create(
                thread_id=self.thread.id,
                role="user",
                content=user_message
            )
            run = self.project.agents.runs.create_and_process(
                thread_id=self.thread.id,
                agent_id=agent.id
            )

            if run.status == "failed":
                return f"Error: {run.last_error}"

            messages = self.project.agents.messages.list(
                thread_id=self.thread.id,
                order=ListSortOrder.ASCENDING
            )
            for msg in reversed(list(messages)):
                if msg.role.name.lower() == "agent" and msg.text_messages:
                    return msg.text_messages[-1].text.value

            return "No response from agent."
        except AzureError as az_err:
            return f"Azure error: {az_err}"
        except Exception as e:
            return f"Unexpected error: {e}"


def main():
    print("🔍 Azure AI Diagnostics Agent with Automation")
    print("Type 'exit' to quit.\n")

    try:
        bot = DiagnosticsAgent()
    except Exception as e:
        print(f"Startup error: {e}")
        sys.exit(1)

    while True:
        try:
            user_input = input("You: ").strip()
            if user_input.lower() in ["exit", "quit", "bye"]:
                print("👋 Goodbye!")
                break
            if not user_input:
                continue

            print("Agent is thinking...\n")
            reply = bot.chat(user_input)
            print(f"Agent: {reply}\n")
        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"Error: {e}\n")


if __name__ == "__main__":
    main()

 