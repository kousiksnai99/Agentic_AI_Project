#!/usr/bin/env python3
"""
Azure AI Diagnostics Agent - Integrated with Azure Automation
Supports Outlook issue diagnostics + running PowerShell scripts via Automation Hybrid Worker
"""
import os
import sys
import time
import uuid
import logging
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential, ClientSecretCredential
from azure.ai.agents.models import ListSortOrder
from azure.core.exceptions import AzureError
from azure.mgmt.automation import AutomationClient
from azure.mgmt.automation.models import RunbookCreateOrUpdateParameters, JobCreateParameters

# =====================
# LOAD CONFIGURATION FROM .env
# =====================
load_dotenv()

AZURE_CLIENT_ID = os.getenv("AZURE_CLIENT_ID")
AZURE_CLIENT_SECRET = os.getenv("AZURE_CLIENT_SECRET")
AZURE_TENANT_ID = os.getenv("AZURE_TENANT_ID")
AZURE_SUBSCRIPTION_ID = os.getenv("AZURE_SUBSCRIPTION_ID")

AZURE_RESOURCE_GROUP = os.getenv("AZURE_RESOURCE_GROUP")
AUTOMATION_ACCOUNT = os.getenv("AUTOMATION_ACCOUNT")
RUNBOOK_NAME = os.getenv("RUNBOOK_NAME")
HYBRID_WORKER_GROUP = os.getenv("HYBRID_WORKER_GROUP")

PROJECT_ENDPOINT = os.getenv("PROJECT_ENDPOINT")
AGENT_ID = os.getenv("AGENT_ID")

# Script mapping remains the same
SCRIPT_MAPPING = {
    "create ost profile": "scripts/create_ost_profile.ps1",
    "start in safe mode": "scripts/start_safe_mode.ps1",
    "check if account is locked or password expired": "scripts/check_account_status.ps1",
    "clearing stored passwords from credential manager": "scripts/clear_stored_passwords.ps1",
    "disable work offline in outlook": "scripts/disable_work_offline.ps1"
}

# Reduce noisy logs
logging.getLogger("azure").setLevel(logging.ERROR)
logging.getLogger("msal").setLevel(logging.ERROR)


class DiagnosticsAgent:
    def __init__(self):
        if not PROJECT_ENDPOINT or not AGENT_ID:
            raise ValueError("Missing PROJECT_ENDPOINT or AGENT_ID in .env")

        # AI Project client
        try:
            self.credential = DefaultAzureCredential()
            self.project = AIProjectClient(
                credential=self.credential,
                endpoint=PROJECT_ENDPOINT
            )
        except Exception as e:
            raise Exception(f"Azure AI client init failed: {e}")

        # Automation client
        try:
            self.automation_credential = ClientSecretCredential(
                tenant_id=AZURE_TENANT_ID,
                client_id=AZURE_CLIENT_ID,
                client_secret=AZURE_CLIENT_SECRET
            )
            self.automation_client = AutomationClient(
                credential=self.automation_credential,
                subscription_id=AZURE_SUBSCRIPTION_ID
            )
        except Exception as e:
            raise Exception(f"Azure Automation client init failed: {e}")

        # Create chat thread
        self.thread = self.project.agents.threads.create()
        print(f"[DEBUG] Created thread: {self.thread.id}")

    # ------------------
    # Run PowerShell script via Automation
    # ------------------
    def run_script(self, problem_key: str) -> str:
        try:
            script_path = SCRIPT_MAPPING.get(problem_key.lower())
            if not script_path or not os.path.exists(script_path):
                return f"No script found for problem: {problem_key}"

            with open(script_path, "r", encoding="utf-8") as f:
                script_content = f.read()

            self.automation_client.runbook.create_or_update(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                runbook_name=RUNBOOK_NAME,
                parameters=RunbookCreateOrUpdateParameters(
                    name=RUNBOOK_NAME,
                    location="eastus2",
                    log_verbose=True,
                    log_progress=True,
                    runbook_type="PowerShell",
                    description=f"Diagnostic runbook for {problem_key}"
                )
            )

            poller = self.automation_client.runbook_draft.begin_replace_content(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                runbook_name=RUNBOOK_NAME,
                runbook_content=script_content
            )
            poller.result()

            publish_poller = self.automation_client.runbook.begin_publish(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                runbook_name=RUNBOOK_NAME
            )
            publish_poller.result()

            job_name = f"{RUNBOOK_NAME}_job_{uuid.uuid4().hex[:8]}"

            job_params = JobCreateParameters(
                runbook={"name": RUNBOOK_NAME},
                run_on=HYBRID_WORKER_GROUP
            )

            job = self.automation_client.job.create(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                job_name=job_name,
                parameters=job_params
            )
            job_id = job.job_id
            print(f"[DEBUG] Started runbook job: {job_id}")

            while True:
                job_status = self.automation_client.job.get(
                    resource_group_name=AZURE_RESOURCE_GROUP,
                    automation_account_name=AUTOMATION_ACCOUNT,
                    job_name=job_name
                )
                if job_status.status.lower() in ["completed", "failed", "stopped"]:
                    break
                time.sleep(5)

            pager = self.automation_client.job_stream.list_by_job(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                job_name=job_name
            )
            print(dir(pager))  # Debugging line to inspect pager object

            output_lines = []
            for stream in pager:
                if hasattr(stream, "stream_text") and stream.stream_text:
                    output_lines.append(f"[{stream.stream_type}] {stream.stream_text}")

            return "\n".join(output_lines) if output_lines else "⚠️ Runbook completed but no output captured."

        except Exception as e:
            return f"Script execution error: {e}"

    # ------------------
    # Chat with agent
    # ------------------
    def chat(self, user_message: str) -> str:
        try:
            for problem in SCRIPT_MAPPING.keys():
                if problem in user_message.lower():
                    return self.run_script(problem)

            agent = self.project.agents.get_agent(AGENT_ID)
            self.project.agents.messages.create(
                thread_id=self.thread.id,
                role="user",
                content=user_message
            )
            run = self.project.agents.runs.create_and_process(
                thread_id=self.thread.id,
                agent_id=agent.id
            )

            if run.status == "failed":
                return f"Error: {run.last_error}"

            messages = self.project.agents.messages.list(
                thread_id=self.thread.id,
                order=ListSortOrder.ASCENDING
            )
            for msg in reversed(list(messages)):
                if msg.role.name.lower() == "agent" and msg.text_messages:
                    return msg.text_messages[-1].text.value

            return "No response from agent."

        except AzureError as az_err:
            return f"Azure error: {az_err}"
        except Exception as e:
            return f"Unexpected error: {e}"


def main():
    print("🔍 Azure AI Diagnostics Agent with Automation")
    print("Type 'exit' to quit.\n")

    try:
        bot = DiagnosticsAgent()
    except Exception as e:
        print(f"Startup error: {e}")
        sys.exit(1)

    while True:
        try:
            user_input = input("You: ").strip()
            if user_input.lower() in ["exit", "quit", "bye"]:
                print("👋 Goodbye!")
                break
            if not user_input:
                continue

            print("Agent is thinking...\n")
            reply = bot.chat(user_input)
            print(f"Agent: {reply}\n")

        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"Error: {e}\n")


if __name__ == "__main__":
    main()
 