################################################################################################# 
## Project name : Agentic AI POC                                                                #
## Business owner , Team : Data and AIA                                                         #
## Notebook Author , Team: POC Team                                                             #
## Date: 29th Oct 2025                                                                          #
## Puprose of Notebook: This file contains the function that will edit the runbook in AA.       #
#################################################################################################

# # Load all the libraries
import config
from azure.identity import DefaultAzureCredential, AzureCliCredential
from azure.mgmt.automation import AutomationClient
from datetime import datetime
def create_new_runbook(runbook_name, system_name):
    cred=DefaultAzureCredential()
    client=AutomationClient(cred, config.SUBSCRIPTION_ID)
    time_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    runbook=client.runbook.create_or_update(
        resource_group_name=config.RESOURCE_GROUP,
        automation_account_name= config.AUTOMATION_ACCOUNT,
        runbook_name=f"{runbook_name}_{system_name}_{time_stamp}",
        parameters={
            "location":config.LOCATION,
            "name": f"{runbook_name}_{system_name}_{time_stamp}",
            "properties":{
                "runbookType":"PowerShell",
                "logProgress": True,
                "logVerbose": False,
                },
                },
                )