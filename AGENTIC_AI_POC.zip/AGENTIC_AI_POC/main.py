import uuid
import json
from config import (
    project_client,
    RUNBOOK_NAME,
    HYBRID_WORKER_GROUP,
    CLASSIFICATION_AGENT_ID,
    TROUBLESHOOTING_AGENT_ID,
    TICKETING_AGENT_ID
)
from workflow_manager import AutoGenWorkflowManager
from automation_handler import save_and_publish_runbook, start_runbook_on_hybrid_worker

def orchestrate_workflow():

    workflow = AutoGenWorkflowManager(
        project_client,
        CLASSIFICATION_AGENT_ID,
        TROUBLESHOOTING_AGENT_ID,
        TICKETING_AGENT_ID
    )

    user_input = input("Hello! Please describe your Outlook issue: ").strip()
    thread = project_client.agents.threads.create()
    thread_id = thread.id
    trace_id = str(uuid.uuid4())
    print(f"Conversation started with Thread ID: {thread_id}")

    workflow.add_task("classify_issue", f"Classify this Outlook issue: {user_input}")
    classi_output = workflow.execute_task("classify_issue", thread_id)
    
    if classi_output and "out of scope" in str(classi_output[0]['text']['value']).lower():
        print("Issue is out of scope. Escalating to ticketing agent.")
        failure_context = f"Issue is out of scope for automated troubleshooting. Original user request: '{user_input}'"
        workflow.add_task("ticketing", failure_context)
        workflow.execute_task("ticketing", thread_id)
        return

    classi_output_text = classi_output[0]['text']['value']
    workflow.add_task(
        "troubleshoot_issue",
        f"Based on the issue summary '{classi_output_text}', provide a complete PowerShell script to resolve it. The script must be self-contained and ready to execute."
    )
    troubleshoot_output = workflow.execute_task("troubleshoot_issue", thread_id)

    if troubleshoot_output and isinstance(troubleshoot_output, list) and troubleshoot_output[0].get('type') == 'text':
        script_content = troubleshoot_output[0]['text']['value']
        
        if "```powershell" in script_content:
            script_content = script_content.split("```powershell\n")[1].split("```")[0]
        
        print("\n--- Generated PowerShell Script ---")
        print(script_content)
        print("-----------------------------------\n")

        save_and_publish_runbook(RUNBOOK_NAME, script_content)
        job = start_runbook_on_hybrid_worker(RUNBOOK_NAME, HYBRID_WORKER_GROUP)

        if job.status == "Failed":
            print("Automated troubleshooting failed. Escalating to ticketing agent.")
            failure_context = f"Troubleshooting attempt failed for issue: '{user_input}'. Automation job '{job.name}' failed with exception: {job.exception}"
            workflow.add_task("ticketing", failure_context)
            workflow.execute_task("ticketing", thread_id)
        else:
            user_satisfied = input("\nThe automated solution was applied. Did this solve your issue? (yes/no): ").strip().lower()
            if user_satisfied in ['n', 'no']:
                failure_context = f"User reported that the automated solution did not resolve the issue. Original request: '{user_input}'."
                workflow.add_task("ticketing", failure_context)
                workflow.execute_task("ticketing", thread_id)
            else:
                success_context = f"Issue resolved successfully via automated runbook. Original request: '{user_input}'."
                workflow.add_task("ticketing", success_context)
                workflow.execute_task("ticketing", thread_id)
    else:
        print("Troubleshooting agent did not return a valid script. Escalating to ticketing.")
        failure_context = f"Troubleshooting agent failed to provide a script for: '{user_input}'"
        workflow.add_task("ticketing", failure_context)
        workflow.execute_task("ticketing", thread_id)

    print("\nWorkflow complete. Final results:")
    print(json.dumps(workflow.results, indent=2, default=str))

if __name__ == "__main__":
    orchestrate_workflow()