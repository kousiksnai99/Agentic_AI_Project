# PowerShell script to search for Outlook's path and start Outlook in Safe Mode

function Get-OutlookPath {
    # Try 64-bit registry first
    $regPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\OUTLOOK.EXE",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\OUTLOOK.EXE"
    )
    foreach ($regPath in $regPaths) {
        try {
            $outlookPath = (Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue).'(Default)'
            if ($outlookPath -and (Test-Path $outlookPath)) {
                return $outlookPath
            }
        } catch {}
    }

    # Try standard install locations if registry fails
    $possiblePaths = @(
        "$env:ProgramFiles\Microsoft Office\root\Office16\OUTLOOK.EXE",
        "$env:ProgramFiles (x86)\Microsoft Office\root\Office16\OUTLOOK.EXE",
        "$env:ProgramFiles\Microsoft Office\Office16\OUTLOOK.EXE",
        "$env:ProgramFiles (x86)\Microsoft Office\Office16\OUTLOOK.EXE"
    )
    foreach ($path in $possiblePaths) {
        if (Test-Path $path) {
            return $path
        }
    }

    return $null
}

$outlookPath = Get-OutlookPath

if (-not $outlookPath) {
    Write-Host "Outlook executable not found. Please check your installation." -ForegroundColor Red
    exit 1
}

# Start Outlook in Safe Mode
Start-Process -FilePath $outlookPath -ArgumentList "/safe"
Write-Host "Outlook is starting in Safe Mode..." -ForegroundColor Green