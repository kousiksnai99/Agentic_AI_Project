##################################################################################### 
## Project name : Agentic AI POC                                                    #
## Business owner , Team : ITOA                                                     #
## Notebook Author , Team: ITOA Project AI Team                                     #
## Date: 7th Dec 2026                                                               #
## Puprose of Notebook:                                                             #                                    #
##   Wrapper service for Azure AI Foundry that resolves a free-text issue to a      #  
##   canonical Automation runbook name.                                             #  
##                                                                                  #  
## Purpose of the runbooks:                                                         #  
##   The runbooks referenced by Foundry are PowerShell diagnostic and remediation   #  
##   scripts. Their purpose is to:                                                  #  
##     - Perform targeted diagnostics (process checks, disk checks, connectivity).  #  
##     - Optionally execute safe, idempotent remediation steps for known issues.    #  
##   Keeping runbooks as separate, named artifacts allows Foundry to select the     #  
##   correct runbook for a given issue and the automation platform to execute it.   #   
## Function Imported:-                                                              #
##     - From utils.py json_response, validate_request_body, get_default_credential #
##       are called.                                                                #
##          - json_response:- This is used to standardise the response              #
##          - validate_request_body:- Function validates the input coming from Kore #
##          - get_default_credential: - To validate using managed identity          #
##     -From app_config load_config_from_dict and AutomationConfig class are        # 
##      imported to load the configuration details like resource group name,        #
##       automation account name                                                    #
#####################################################################################  

## Load all the libraries
from typing import Any, Dict, Optional, Tuple               # To describe the kind of data being used 

# Loads all settings from config file:
#   - Foundry Endpoint
#   - Agent IDs
#   - Deployment Name
#   - Api Version
from app_config import load_config_from_dict, FoundryConfig

# Helper functions imported from utils file
from utils import json_response, validate_request_body, get_default_credential

# Client for azure ai foundry it allows to Connect to an AI Foundry Project, manage agent, run conversation, manage threads etc.
# AI foundry project is a container to ai assets like agents, models, tools etc.
from azure.ai.projects import AIProjectClient
from azure.ai.agents.models import ListSortOrder    # Sort agents Output
from datetime import datetime

import logging 
#=============================Logging Setup========================================================
# Azure Functions configures the root logger; we explicitly set level here to be explicit about expected verbosity.
logging.getLogger().setLevel(logging.INFO) # Ensure at least INFO logs are emitted

# Load all the configuration.
config, foundry_dict, automation_dict = load_config_from_dict()
#=============================================Azure AI Foundry==========================================

class FoundryAgentService: 
    """
    Service wrapper for interacting with Azure AI Foundry agents.
    This is a generic class however diagnostic agent is called during initialization. 
  
    Why this class exists:  
    - Separates Foundry-specific API usage from orchestration code so callers can  
      ask "which runbook should I run?" without needing Foundry SDK details.  
    - Centralizes request/response and minimal retry/inspection logic so we can  
      maintain and test agent resolution in one place.  
  
    High-level behavior:  
    - __init__: initialize AIProjectClient and pre-load the diagnostic agent reference.  
    - resolve_runbook_from_issue: send the issue text to the diagnostic agent,  
      run the agent, read back messages and attempt to resolve the runbook name.  
  
    Returns:  
    - resolve_runbook_from_issue returns a tuple (resolved_runbook_name, Resolve_Logger)  
      where resolved_runbook_name may be None if the agent failed to resolve a runbook,  
      and Resolve_Logger is a dictionary containing timestamps and minimal telemetry for debugging. 

    """


    def __init__(self, config: FoundryConfig, credential: get_default_credential):
        """
        Initializes foundry service with foundry project configuration and credentials.
        This constructor:
            - Stores foundry configuration
            - Create AIproject client
            - Caches diagnostic agent reference for faster runtime calls
        
        Args:
            - config: Foundry configuration containingendpoint and agentID.
            - credential:Azure managed identity credential to authenticate foundry.
        
        Example:

            - foundry_cfg = FoundryConfig(
                endpoint= 'https://foundry-endpoint.azure.com',
                diagnostic_agent_id= 'agent-12345',
                troubleshoot_agent_id= 'agent-123456',
                deployment= 'ITOA-Service_Desk-Agentic_AI_POC-gpt-5-mini',
                api_version= '2024-12-01-preview'
                )
            
            - credential = get_default_credential()
            - service = FoundryService(foundry_cfg, credential)
            - print(service.diagnostic_agent_id)

            - Output:
                - agent-12345

        """
        self.config = config    # store Foundry configuration so methods can access endpoint, agent ids, etc. and keep config for reuse
        
        # create the AIProjectClient with the given endpoint and credential to access Foundry Project APIs  
        # create client used to interact with Foundry
        self.project = AIProjectClient(endpoint= config.endpoint, credential=credential)    # instantiate Foundry client
        

         # pre-fetch the diagnostic agent object referenced by id to avoid repeated lookups at runtime  
         # cache agent reference for efficiency  
        self.agent = self.project.agents.get_agent(self.config.diagnostic_agent_id) # get agent metadata/object by id  
    
    
    def resolve_runbook_from_issue(self, issue_text: str) ->Optional[str]:
        """
        Sends the issue to the diagnostic agent and expects a final message
        that contains the resolved runbook name.
        This method sends the provided issue description to the foundry diagnostics agent,
        which analyzes the problem and determines the most appropriate runbook to execute. 
        The agent is expected to return a final response containing the runbook name

        Why:  
        - We rely on Foundry's diagnostic agent to map free-text issues to the canonical runbook name.  
        - Returning a structured Resolve_Logger alongside the result helps with observability and debugging.  
  
        Args:  
        - issue_text: the free-text issue description supplied by caller.  
  
        Returns:  
        - (resolved_runbook_name, Resolve_Logger)  
          resolved_runbook_name: str or None if no runbook was identified  
          Resolve_Logger: dict containing timestamps and stages for visibility into the Foundry call lifecycle 

        Example:
        - issue = "Outlook is not opening"
        - runbook = service.resolve_runbook_from_issue(issue)
        - print(runbook)
        - Output:
            - (Diagnostic_KB002605, {dictionary containing time for each process}
        """
        Resolve_Logger={}   # initialize a dictionary to capture timestamps and stages for later debugging

        # create telemetry container  
        logging.info("Sending issue to Foundry diagnostic agent.")          # log intent for observability
        
        # notify that resolution is starting 
        # 'Z' is the zone designator for the zero UTC offset, indicating that the time is in Coordinated Universal Time (UTC) 
        Resolve_Logger['Thread_Start_Time']=datetime.utcnow().isoformat() +'Z'   # mark when we begin thread creation  # timestamp start 
        thread = self.project.agents.threads.create()                       # create a new conversation thread so messages and runs are isolated
        # 'Z' is the zone designator for the zero UTC offset, indicating that the time is in Coordinated Universal Time (UTC)
        Resolve_Logger['Thread_End_Time']=datetime.utcnow().isoformat() +'Z'     # record when thread creation finished  # timestamp end 
        # 'Z' is the zone designator for the zero UTC offset, indicating that the time is in Coordinated Universal Time (UTC)
        Resolve_Logger['Message_Start_Time']=datetime.utcnow().isoformat() +'Z'  # record when we start sending the user's message  # timestamp  
        
        self.project.agents.messages.create(        # post the user's issue text as a message in the thread  # submit message  
            thread_id=thread.id,                    # associate message to created thread  # reference thread  
            role='user',                            # mark message role as 'user' so agent knows it's user input  # set role 
            content=issue_text                      # the actual issue text we want the agent to process  # message content
        )
        # 'Z' is the zone designator for the zero UTC offset, indicating that the time is in Coordinated Universal Time (UTC)
        Resolve_Logger['Message_End_Time']=datetime.utcnow().isoformat() +'Z'    # record completion of message creation  # timestamp  
        # 'Z' is the zone designator for the zero UTC offset, indicating that the time is in Coordinated Universal Time (UTC)
        Resolve_Logger['Run_Start_Time']=datetime.utcnow().isoformat() +'Z'      # mark when we request agent processing to start  # timestamp
        run = self.project.agents.runs.create_and_process(                  # instruct Foundry to create and execute a run for the thread  # trigger run  
            thread_id=thread.id,                                            # run against the thread we created  # reference thread  
            agent_id=self.agent.id,                                         # run the configured diagnostic agent  # choose agent  
            )
        # 'Z' is the zone designator for the zero UTC offset, indicating that the time is in Coordinated Universal Time (UTC)    
        Resolve_Logger['Run_End_Time']=datetime.utcnow().isoformat() +'Z'        # record when the run request finished  # timestamp  

        if run.status == "failed":                                          # check if the run failed according to Foundry  # inspect run status  
            logging.error("Foundry run failed. Error: %s")                  # log an error to help diagnostics (no specific error string available here)  # log failure  
            return None                                                     # return None for runbook name, but include Resolve_Logger for debugging  # return failure
        
        # 'Z' is the zone designator for the zero UTC offset, indicating that the time is in Coordinated Universal Time (UTC)
        Resolve_Logger['Order_Start_Time']=datetime.utcnow().isoformat() +'Z'    # record when we start listing messages  # timestamp  
        messages = self.project.agents.messages.list(                       # fetch all messages for the thread so we can inspect agent responses  # read messages  
            thread_id = thread.id,                                          # limit messages to our thread  # reference thread  
            order = ListSortOrder.ASCENDING,                                # request messages in ascending order to read from earliest to latest  # ordering
        )

        # 'Z' is the zone designator for the zero UTC offset, indicating that the time is in Coordinated Universal Time (UTC)
        Resolve_Logger['Order_End_Time']=datetime.utcnow().isoformat() +'Z'      # mark when message list retrieval finished  # timestamp 
        resolved_runbook_name: Optional[str] = None                         # initialize result variable to None; will set if agent returned a candidate  # prepare result  
        
        # 'Z' is the zone designator for the zero UTC offset, indicating that the time is in Coordinated Universal Time (UTC)
        Resolve_Logger['Msg_Read_Start_Time']=datetime.utcnow().isoformat() +'Z' # timestamp for starting message inspection  # timestamp  
        for message in messages:                                            # iterate messages to find text responses from the agent  # iterate responses 
            if not message.text_messages:                                   # skip messages that don't contain text payloads  # guard for empty text  
                continue                                                    # continue to next message if no text messages present  # skip  
            resolved_runbook_name= message.text_messages[-1].text.value     # read the last text chunk's value as the candidate runbook name  # extract runbook 
        
        # 'Z' is the zone designator for the zero UTC offset, indicating that the time is in Coordinated Universal Time (UTC)
        Resolve_Logger['Msg_Read_End_Time']=datetime.utcnow().isoformat() +'Z'   # mark message inspection end time  # timestamp  
        
        # if agent returned some text, log that we resolved a users query for runbook name  # check result 
        if resolved_runbook_name:           
            # write informational log with resolved runbook name  # log resolved runbook 
            logging.info(
                "Foundry diagnostic agent resolved runbook '%s'.",
                resolved_runbook_name,
            )
        # if resolution failed, log a warning so operators can follow up  # handle no result  
        else:
            logging.warning(    # warn that no runbook was resolved by agent  # log missing result  
                "Foundry diagnostic agent did not return a runbook name."
            )
        
        # return the candidate runbook name (or None) along with the logger dict  # return tuple  
        return resolved_runbook_name, Resolve_Logger