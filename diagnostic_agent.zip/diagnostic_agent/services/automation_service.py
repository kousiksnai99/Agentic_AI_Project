##################################################################################### 
## Project name : Agentic AI POC                                                    #
## Business owner , Team : ITOA                                                     #
## Notebook Author , Team: ITOA Project AI Team                                     #
## Date: 7th Dec 2026                                                               #
## Puprose of Notebook:                                                             #                                    
##   Centralize Azure Automation interactions used by the Agentic AI POC.           #  
##   - Acquire tokens for Azure Resource Management REST calls                      #  
##   - Fetch runbook content, clone/annotate, publish and start runbooks            #  
##   - Poll and retrieve job outputs                                                #  
## Note:-                                                                           #
##     - From utils.py json_response, validate_request_body, get_default_credential #
##       are called.                                                                #
##          - json_response:- This is used to standardise the response              #
##          - validate_request_body:- Function validates the input coming from Kore #
##          - get_default_credential: - To validate using managed identity          #
##     -From app_config load_config_from_dict and AutomationConfig class are        # 
##      imported to load the configuration details like resource group name,        #
##       automation account name                                                    #
#####################################################################################  

## Load all the libraries
from typing import Any, Dict, Optional, Tuple   # To describe the kind of data being used 

# Loads all settings from config file:
#   - Azure Subscription
#   - Resource Group
#   - Automation Account Name
#   - Location of the service
from app_config import load_config_from_dict, AutomationConfig

# Helper functions imported from utils file
from utils import json_response, validate_request_body, get_default_credential

# Azure Library to control azure automation. 
# Let us create and manage runbooks, extract the output of runbook execution.
from azure.mgmt.automation import AutomationClient
from datetime import datetime                   # To work with date time
import requests                                 # To call external api
import logging                                  # Write logs for debugging

# Load all the configuration.
config, foundry_dict, automation_dict = load_config_from_dict()

#=============================Logging Setup========================================================
# Azure Functions configures the root logger; we explicitly set level here to be explicit about expected verbosity.
logging.getLogger().setLevel(logging.INFO) # Ensure at least INFO logs are emitted

class AzureautomationService:
    """
    Wrapper around azure automation operations (Runbook CRUD, REST content).  
      - Encapsulates interactions with Azure Automation (create/update runbooks,  
        upload content, publish, start jobs, and fetch job outputs).  
      - Provides helper to acquire ARM REST bearer tokens via managed identity.  
  
    Why:  
      - Keeps authentication and SDK/REST details centralized so higher-level  
        orchestration code remains simple and testable.  
      - Uses fail-fast / clear logging to assist troubleshooting while ensuring  
        telemetry / automation operations do not crash the main application.  
    """

    def __init__(self, config: AutomationConfig, credential: get_default_credential):
        """
        Initialize service with typed configuration and an Azure credential.  
          - Stores config and credential for reuse across methods.  
          - Creates an AutomationClient using the provided credential so we can use  
            the management SDK for resource-level operations where available.      
        Why:  
          - If the SDK or credential is not available the client[client can be a user or function] 
           will be None and the service will log warnings — callers should handle None or rely on  
           REST fallbacks.  

        Args:  
          config: AutomationConfig dataclass containing subscription_id, resource_group,  
                  automation_account, location etc.  
          credential: DefaultAzureCredential (managed identity) used for ARM token acquisition  
                      and where required by SDKs.      
        
        Example:
            - automation_cfg =AutomationConfig(
                subscription_id= 'xxxxxxxxxxxxxxxxxx',
                resource_group = 'aiorg',
                automation_account = 'test_automation',
                location = 'Sweden_Central',
                Hybrid_runbook_worker='Agentic_AI_POC_SCCM'
        )           
            - credential = get_default_credential()
            - service = AzureautomationService(automation_cfg, credential)
            - print(service.resource_group)

            - Output:
                - aiorg

        """
        self.config=config          # store automation config for later calls 
        self.credential=credential  # store credential for token acquisition  
        self.client = AutomationClient(credential, config.subscription_id)  # create Azure Automation SDK client  
     
    def get_rest_token(self) -> str:
        """
        Acquire an access token for Azure Resource Manager using managed identity. 
        Requests an OAuth bearer token for the 'https://management.azure.com/.default' scope using 
        the configured azure credential [Managed Identity].  
        
        Why:  
            Some REST endpoints (raw content / output) are only available via  
            ARM REST and not via the high-level SDK; a bearer token is needed.  

        Args:
          - This is a zero argument function
        Returns:  
          - A bearer token string suitable for Authorization: Bearer <token> header which is valid for 1 hour.  
        Raises:  
          - RuntimeError if credential is not available (fail fast with clear message).  
          
        Example:
          - token = self.get_rest_token():
          - Output: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
        """
        token = self.credential.get_token("https://management.azure.com/.default").token    # get token string  
        
        # return the token to be used in Authorization headers for REST calls  
        return token  # token valid for a limited period (usually 1 hour)   
                                               

    def fetch_runbook_content(self, runbook_name: str) -> Optional[str]:
        """
        Fetch the raw content of an azure automation runbook via ARM [Azure Resource Management] REST API.    
          - Builds the ARM URL for runbook content and GETs the response bytes.  
          - Decodes bytes to UTF-8 string and returns script text.  
  
        Why:  
          - The management SDK sometimes abstracts or omits raw script content;  
            fetching via ARM REST ensures access to the exact bytes for cloning or editing.  
          - We use REST to ensure compatibility across regions and API versions.  
  
        Args:
          - runbook_name: Runbook name whose content should be fetched.

        Returns:  
          - The runbook script text if found, otherwise None.  
  
        Notes:  
          - This method raises if credential is missing; callers can catch exceptions and handle them.


        Example:
          - script_content= fetch_runbook_content('Test_Runbook') #Extract content of Test_Runbook  
          - print(script_content)
          - Output:
              # This is a test runbook
        """
        token=self.get_rest_token() # acquire a REST bearer token for ARM calls (reuses managed identity)
        
        # build the ARM REST URL referencing subscription, resource group, automation account and runbook 
        # example: https://management.azure.com/subscriptions/subscription_id/resourceGroups/aoairg/providers/Microsoft.Automation/automationAccounts/test_automation/runbooks/diag_KB002605/content?api-version=2024-10-23
        url = (
            f"https://management.azure.com/subscriptions/{self.config.subscription_id}"
            f"/resourceGroups/{self.config.resource_group}"
            f"/providers/Microsoft.Automation/automationAccounts/{self.config.automation_account}"
            f"/runbooks/{runbook_name}/content?api-version=2024-10-23"
            )   # REST endpoint for runbook content (specific api-version ensures stability)  
        
        # prepare headers including authorization and an accept header for binary/octet-stream responses      
        headers = {
            "Authorization": f"Bearer {token}",     # supply bearer token for ARM auth
            "Accept": "application/octet-stream"    # request raw content bytes  
            }
        # perform HTTP GET to download the runbook content
        response = requests.get(url, headers=headers)    # call ARM REST to retrieve content  
        
        # if response is OK then decode bytes to UTF-8 string and return  
        if response.status_code == 200:
            logging.info("Fetched content for runbook '%s'.", runbook_name) # log success with runbook name 
            return response.content.decode("utf-8", errors="ignore")        # return decoded script text  
        
        # log a warning including status code and text if retrieval failed  
        logging.warning(
            "Failed to fetch content for runbook '%s'. status: %s, Bodr: %s",
            runbook_name,
            response.status_code,
            response.text,
            )   # record details to help troubleshoot REST failures  
        
        # return None for callers to handle absence of content 
        return None

    def create_or_update_runbook(self, runbook_name: str, runbook_content: str) -> None:
        """
        Create or update a runbook, upload content, publish it and start execution on a Hybrid Worker.  
        Ensures runbook metadata exists (create_or_update)  
        Uploads script content to the runbook draft (replace content)  
        Publishes the runbook (draft -> published)  
        Creates a job resource that triggers the runbook to execute on the specified Hybrid Worker Group 

        This method sends the provided issue description to the foundry diagnostics agent, which analyzes the 
        problem and determines the most appropriate runbook to execute. The agent is expected to return a final 
        response containing the runbook name.
        
        Why:  
          - Need to create new notebook in azure automation from existing published diagnostic scripts in Azure automation account.  
          - Returning identifiers (job_name, job_id) allows callers to poll for output or present results to users.  
  
        Args:
          - runbook_name: Name of azure automation runbook that needs to be created.
          - runbook_content: Powershell code that must be added to the new runbook.
          - hybrid_worker_group:
        Returns:  
          - A tuple (job_name, job_id) used to identify and poll for job outputs.  
  
        Notes:  
          - Method assumes the AutomationClient SDK is available and the credential has permissions.  
          - Polling, retries, and error handling are kept minimal here; callers can add additional resilience if required. 
        
        Example:
          - script = '''
            write-output "Starting diagnostic"
            '''
          - automation.create_or_update_runbook(runbook_name='diag_runbook', runbook_conent=script)
          - Output:
              #runbook is created by name diag_runbook which contains starting diagnostic as content
              (diag_runbook, 'xxxxxxxxx')
        
        """
        # log start of create/update operation so execution can be traced  
        logging.info("Creating or updating runbook '%s'.", runbook_name)     # helpful for tracing and monitoring
        hybrid_worker_group= self.config.hybrid_worker_group                 # hybrid worker group that contains interface VM[interface VM is onboarded to azure via Azure Arc]
        # 1. Create or Update Runbook metadata (ensures runbook exists) 
        runbook = self.client.runbook.create_or_update(
            resource_group_name = self.config.resource_group,           # RG containing automation account 
            automation_account_name= self.config.automation_account,    # automation account name  
            runbook_name = runbook_name,                                # requested runbook name 
            parameters={                            # metadata properties for the runbook  
                "location": self.config.location,   # set location for runbook resource                           
                "properties" : {
                    "runbookType": "PowerShell",    # declare runbook scripting language
                    "logProgress": False,           # disable verbose progress logging (configurable) 
                    "logVerbose": False,            # disable verbose logs to reduce noise 
                }
            }
        )  # create_or_update ensures resource exists and returns metadata  

        # log resource id returned by SDK so we can correlate resources in logs             
        logging.info(
            "Runbook metadata ensured for '%s'.Resource ID: %s",
            runbook_name,
            runbook.id
            )       # runbook.id is helpful for debugging or audit 
      
        # 2. Upload content to the Draft of the runbook (replace draft content)  
        draft_poller = self.client.runbook_draft.begin_replace_content(
            resource_group_name= self.config.resource_group,            # RG name 
            automation_account_name=self.config.automation_account,     # automation account name  
            runbook_name = runbook_name,                                # name of runbook to update draft for  
            runbook_content = runbook_content                           # actual script content to upload  
        )   # begin_replace_content returns a poller we must wait on  


        # wait for the draft content upload to complete (blocking call)  
        draft_poller.result()       # ensures the draft content upload is finished before moving on  

        # log success of content upload for observability 
        logging.info("Runbook draft content uploaded for'%s'", runbook_name)    # indicate content update finished 


        # 3. Publish the runbook so that it is available for execution (draft -> published) 
        #   Azure runbook publishing is an asynchronus long-running operation. The begin_publish call triggers the publish proocess
        #   and returns a poller object instead of waiting for completion.
        #   Poller is used to track the status of the publish operation and allows us to explicitly wait until azure finishes publishing the runbook.
        #   This guarantees that the runbook is fully published & available for execution. 
        publish_poller=self.client.runbook.begin_publish(
            resource_group_name=self.config.resource_group,         # RG name for publish call  
            automation_account_name=self.config.automation_account, # automation account  
            runbook_name = runbook_name,                            # which runbook to publish 
        )   # begin_publish returns a poller 

        # wait for publish operation to finish so subsequent run uses published version
        publish_poller.result()
        # log that the runbook is published for monitoring 
        logging.info("Runbook '%s' published successfully.", runbook_name)  # published runbook is now runnable

        # 4. Execute the runbook on a Hybrid Worker Group (used to run scripts on-premises) 
        logging.info("Starting runbook execution on Hybrid Worker Group: %s", runbook_name) # informational log 
        
        # prepare a job name to create a job resource (helps with idempotency and tracking)
        job_name = f"job_{runbook_name}"

        # create the job resource which triggers the runbook run on target Hybrid Workers 
        job = self.client.job.create(
            resource_group_name=self.config.resource_group,         # RG containing automation account 
            automation_account_name=self.config.automation_account, # automation account name
            job_name=job_name,                                      # job name to create
            parameters={
                "properties": {
                    "runbook": {"name": runbook_name},              # instruct job to run this runbook 
                    "parameters": {},                               # pass any runbook params (empty here) 
                    "runOn": hybrid_worker_group                    # Hybrid Worker Group name (target environment) 
                }
            }
        )                                                           # job creation triggers execution on hybrid worker group specified  

        # log job id returned by SDK so we can refer to it for output retrieval
        logging.info(
            "Runbook execution started on Hybrid Worker Group. Job ID = %s",
            job.id
        )   # job.id uniquely identifies this runbook execution instance  

        # return the job name and job id so caller can poll for outputs or return to clients
        return job_name, job.job_id     # provide identifiers to track and fetch output later  

########################FUNCTION: get_output_by_runbook_name######################
    def get_runbook_output(self,job_name: str, job_id: str) -> str:
        """
        Poll azure automation job status until it reaches terminal state and then  fetch the job output via ARM REST.  
        Polls the job status via the AutomationClient SDK until it reaches a terminal state (Completed/Failed/Stopped).  
        Once terminal state is reached, uses ARM REST and a bearer token to fetch the job output.  

        Why:  
          - Need this function to retrieve the execution output of an Azure Automation Runbook after it has been triggered.
          - When a runbook is started, Azure Automation executes it asynchronusly and immediately returns a Job_id. 
          - Actual execution happens in the background and may take several minutes. Because of this runbook output is not available immediately.
          - Available states are New, Running, Suspended, Completed, Failed and Stopped   
        Arg:
          - job_name: Name of the automation job"
          - job_id: Unique job identifier returned when runbook was started.

        Returns:  
          - The job output text if available, otherwise None.   
        
        Example:
          job_name, job_id= automation.create_or_update_runbook('diag_runbook', script)
          automation.get_runbook_output('diag_runbook,'xxxxxxx')
          Output:
            - Outlook is missing ost file
        """

        # continuously poll the job status until it's completed, failed, or stopped 
        while True:
            job_status = self.client.job.get(
                resource_group_name=self.config.resource_group,         # RG for job  
                automation_account_name=self.config.automation_account, # automation account  
                job_name=job_name                                       # job name used to get job status 
            ).status    # read status property returned by SDK 

            # break out of the loop once job reaches a terminal state (completed/failed/stopped)  
            if job_status.lower() in ["completed", "failed","stopped"]:
                break        # exit polling when job ended
            
            # otherwise wait a short interval before polling again to avoid tight-looping  
            time.sleep(5)   # sleep to throttle polling and avoid rate-limits  

        # after completion, acquire REST token for accessing job output endpoint
        token=self.get_rest_token() # get bearer token for ARM REST output call  
        
        # build the job output ARM REST URL using subscription and job id 
        # https://management.azure.com/subscriptions/xxxxxxxxxxx/resourceGroups/aoairg/roviders/Microsoft.Automation/automationAccounts/test_automation/jobs/{job_id}/output?api-version=2023-11-01
        output_url = (
            f"https://management.azure.com/subscriptions/{self.config.subscription_id}"
            f"/resourceGroups/{self.config.resource_group}"
            f"/providers/Microsoft.Automation/automationAccounts/{self.config.automation_account}"
            f"/jobs/{job_id}/output?api-version=2023-11-01"
        )   # job output endpoint (api-version selected to be compatible)  

        # prepare headers for REST call, include authorization and accept octet-stream 
        headers = {
            "Authorization": f"Bearer {token}",     # supply bearer token for ARM auth
            "Accept": "application/octet-stream"    # expect raw output  
            }
            # perform the GET request to retrieve job output from ARM 
        
        response = requests.get(output_url, headers=headers)    # call ARM to fetch job output 

        # if successful, log and return text body  
        if response.status_code == 200:
            logging.info("Fetched output for the job '%s'.", job_id)    # log when output retrieval succeeds 
            return response.text                                        # return output content as text for caller consumption  

        # if not successful, log a warning with status and body to ease troubleshooting 
        logging.warning(
            "Failed to fetch the output '%s'. status: %s, Bodr: %s",
            job_id,
            response.status_code,
            response.text,
            )   # capture REST failure details in logs
        
        # return None so callers can detect missing output
        return None

    def clone_runbook_with_metadata(self, source_runbook_name: str, system_name: str, issue_text: str, environment: str, session_id: str, loggedin_username: str) -> str:
        """
        Clone an existing runbook, prepend metadata as header, publish and execute it.  
        Fetches source runbook [Runbook that agent selects Diagnose_KB002065] content via REST.  
        Prepares an annotated script by adding header metadata (device, user, session).  
        Creates/updates a new runbook with the annotated content, publishes it, and starts it.  
        
        Args:
          - source_runbook_name: Name of existing runbook to be cloned.
          - system_name: Target system or device name where scripts needs to be executed.
          - issue_text: Summary of the issue that is used for the diagnostic agent as input.
          - environment: Environment type [dev, test, prod]
          - session_id: unique session identifier for traceabilty provided by kore.AI
          - loggedin_username: Username captured from microsoft teams by kore.AI

        Why:  
          - Cloning allows us to run diagnostics tied to a specific machine/session without  
            modifying the original runbook. The header provides runtime variables the script can use.  
        
        Returns:  
          - Tuple of (new_runbook_name, job_name, job_id) so callers can poll or present results.  
        
        Raises:  
          - ValueError if the source runbook content could not be fetched.

        Example:
          - cloned_name, job_name, job_id = automation_service.clone_runbook_with_metadata(
              source_runbook_name= runbook_name,   
              system_name = target_machine,       
              issue_text = issue,                  
              environment = config.environment,   
              session_id=session_id,               
              loggedin_username=loggedin_username  
              )
          - Output:
              # Job is getting executed on user machine.
              ( cloned_name=diag_runbook_session_id
              job_name= 'diag_runbook', 
              job_id= 'xxxxxxxxx')
        """

        # fetch the original runbook content via REST; if None raise to be handled by caller  
        original_content=  self.fetch_runbook_content(source_runbook_name)  # get the existing runbook script  

        if original_content is None:
            raise ValueError(f"No content returned for runbook '{source_runbook_name}'")    # fail fast if missing 

        # create a timestamp to aid in naming and traceability (not currently used in name but useful if needed) 
        timestamp= datetime.utcnow().strftime("%Y%m%d_%H%M%S")  # timestamp useful for unique naming or logs  
        
        # small convenience prefix (kept for potential future use in script body) 
        source_script = f"$SystemName:{system_name}\n"      # include system name line for script context (unused variable ok) 
        
        # construct a new runbook name combining source name, target system and session id for uniqueness and readability 
        new_runbook_name = f"{source_runbook_name}_{system_name}_{session_id}"  # ensures clone is identifiable with a unique name  


        # header_block contains lines to prepend to the original script to provide runtime metadata and setup
        header_block = [
            f"# Generated by Agentic Automation Team- ",    # comment identifying auto-generated script provenance  
            f"$ScriptName = '{new_runbook_name}'",          # set runtime variable with script name (PowerShell)  
            f"$DeviceName = '{system_name}' ",              # set runtime variable with device name  
            f'$Loggedin_Username = "{loggedin_username}" ',  # set username variable (mapped)  
            f"Import-Module ($Env:SMS_ADMIN_UI_PATH.Substring(0,$Env:SMS_ADMIN_UI_PATH.Length-5) + '\ConfigurationManager.psd1')",  # import SCCM module using environment path  
            f"cd CBL:",                             # change directory to expected working dir (CBL:)  
            f"# Step 1: Inline script content",     # marker for where original content starts  
            f"$scriptText = @'",                    # begin here-doc style multiline string in PS if used downstream  
            f'$Loggedin_Username = "{loggedin_username}" ',   # repeat username inside script text block for SCCM server 
            ]       # header_block is a list of strings to join and prepend to original script content  
        
        # join the header lines and append the original content to produce the annotated script to upload
        annotated_content = "\n".join(header_block) + original_content   # final script content to upload into new runbook  

        # create or update the cloned runbook, upload content, publish it, and trigger a job; returns job identifiers  
        job_name, job_id=self.create_or_update_runbook(new_runbook_name, annotated_content)        # publish & run clone 
        
        # return the new runbook name plus job identifiers for caller use  
        return new_runbook_name,job_name,job_id # return triple: cloned name, job name and job id  
