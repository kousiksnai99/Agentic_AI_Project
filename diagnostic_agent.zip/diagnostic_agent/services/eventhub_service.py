######################################################################################### 
## Project name : Agentic AI POC                                                        #
## Business owner , Team : ITOA                                                         #
## Notebook Author , Team: ITOA Project AI Team                                         #
## Date: 7th Dec 2026                                                                   #
## Puprose of Notebook:                                                                 #
## Provides a small wrapper around Azure Event Hub producer to emit JSON telemetry      #
## events using Azure AD (managed identity) authentication. This module intentionally   #
## fails telemetry operations silently (logs errors) so that telemetry does not         #
## interrupt primary business logic.                                                    #
## Function Imported:-                                                                  #
##     - From utils.py json_response, validate_request_body, get_default_credential     #
##       are called.                                                                    #
##          - get_default_credential: - To validate using managed identity              #
#########################################################################################  

# # Load all the libraries
from typing import Any, Dict, Optional  # Load all the configuration.
import json                             # Convert data to json format
import logging                          # Logging messages and warning 

# Azure eventhub library
#   -EventHubProducerClient:- Client to send events data to eventhub. It connects to eventhub name space and sends data reliably.
#   -EventData:-To convert data into event data format. Eventhub accepts data in this format
from azure.eventhub import EventHubProducerClient, EventData  
from utils import get_default_credential                      # Helper function logs azure securely using managed identity
import time                                                   # implement delay

#============================================Event Hub Logging==========================================
class EventHubLogger:
    """
    Lightweight Event Hub telemetry emitter using Azure AD credentials.  
  
    What:  
      - Sends JSON-serialised events to a configured Azure Event Hub.  
      - Uses AAD (DefaultAzureCredential) to avoid connection-string secrets.  
      - If Event Hub is not configured or the SDK is unavailable, the instance  
        becomes a no-op emitter that logs locally.  
  
    Why:  
      - Centralizes telemetry emission and configuration.  
      - Ensures telemetry failures never raise to application code (fail-safe).  
      - Using AAD (managed identity) avoids embedding or rotating connection strings.  

    """
   
    def __init__(self, automation_dict: Dict[str, Any], credential: get_default_credential):
        """
        Initialize the EventHubLogger.  
  
        Args:  
          automation_dict: optional dictionary with context for telemetry (kept  
                           for backward compatibility / enrichment).  
          credential: an authenticated DefaultAzureCredential (managed identity).  
          namespace: fully-qualified Event Hub namespace (e.g. 'mynamespace.servicebus.windows.net').  
                     If not provided, the constructor will attempt to read AGENTIC_EVENTHUB_NAMESPACE env var.  
          eventhub_name: name of the Event Hub to send to. If not provided, AGENTIC_EVENTHUB_NAME env var is used.  
  
        Behavior:  
          - If the Event Hub SDK or credentials are unavailable, the instance will  
            be created but all send_event calls will be no-ops.  
          - Constructor logs status for observability but does not raise on failures.
        
        Example 1: Successful initialization
          - Input:
            credential = DefaultAzureCredential()
            automation_context ={
              "app_name": "diagnostic_agent",
              "environment": "dev",
              "region": "sweden_central"
              }
            logger = EventHubLogger(automation_context, credential)     #Successfully initialized and authenticated     
        """ 

        # allow caller or environment to provide the namespace and hub name  
        namespace ="ehn-hrmqc-ais-swce-poc.servicebus.windows.net" # Event Hub namespace (hard-coded for POC)  
        name="evh-okvkc-ais-swce-poc"       # Event Hub name

        # If SDK or configuration missing, make this a no-op logger
        if not namespace or not name:       # check configuration presence
            logging.warning(
                "Event Hub namespace/name not configured. Event will not be sent."
                )                           # warning if missing
            self.producer: Optional[EventHubProducerClient] = None  # no producer available  
            return  # early return, logger will be no-op 
        
        # Try to create a producer client with the provided credential. 
        try:
            # Use the DefaultAzureCredential passed in (typically managed identity).
            self.producer= EventHubProducerClient(      # instantiate producer  
                fully_qualified_namespace = namespace,  # set namespace
                eventhub_name = name,                   # set event hub name
                credential= credential                  # supply credential
            )
            logging.info("Event Hub Logger initialised for hub '%s'.", name)    # success log
        except Exception:
            logging.exception("Failed to initialise Eventhub producer client.") # log exception 
            self.producer=None                                                  # mark producer as unavailable
    
    def send_event(self, event: Dict[str, Any]) -> None:
        """
        Send a single JSON event to Event Hub.  
  
        What:  
          - Serializes the `event` dict to JSON and sends it as a single EventData  
            within a batch to the configured Event Hub.  
          - Adds optional automation/context fields from the automation_dict passed  
            to the constructor for easier downstream filtering/diagnostics.  
  
        Args:  
          event: dictionary containing event payload (will be serialized with json.dumps).  
          partition_key: optional partition key to target a specific partition.  
  
        Why:  
          - Telemetry is best-effort: failures are logged and swallowed so they  
            do not affect primary application behavior.  
          - Batching is used even for single events to follow the Event Hub SDK API. 

        Example:
          Input: 
            agent_event_dictionary = {
                                      "Agent_ID":"XXXXXXXXXXXX",
                                      "Agent_Message": "What is the capital of france"    
                                      }
            send_event(agent_event_dictionary)
          Output: Event sent to Event Hub
        """
        # No producer configured (SDK missing, misconfigured or disabled) => no-op
        if not self.producer:   # if no producer configured, do nothing 
          print("No producer")
          return              # no-op when telemetry not configured 
        
        try:
        
          payload = json.dumps(event)       # serialize event to JSON string  
          event_data =EventData(payload)    # wrap payload into EventData  
          with self.producer:               # context-manage the producer
            batch = self.producer.create_batch()    # create an event batch  
            time.sleep(1)                           # sleep is added to account for the lag that is there with create_batch function.
            batch.add(event_data)                   # add the serialized event
            self.producer.send_batch(batch)         # send the batch 
            time.sleep(1)                           # sleep is added to account for the lag that is there with send_batch function.
          logging.info("Event sent to Event Hub: %s", event.get("event_type"))    # log success
        except Exception as authentication_exception:
          print("Failed to send", authentication_exception)
          logging.exception("Failed to send event to eventhub.")  # log but do not raise any issue  

