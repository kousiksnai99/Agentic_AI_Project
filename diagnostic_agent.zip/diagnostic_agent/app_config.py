##################################################################################### 
## Project name : Agentic AI POC                                                    #
## Business owner , Team : ITOA                                                     #
## Notebook Author , Team: ITOA Project AI Team                                     #
## Date: 7th Dec 2026                                                               #
## Purpose of Notebook:                                                             #
## This module centralizes configuration for the Agentic AI POC. It provides:       #
##  - Typed dataclasses that describe the shape of configuration used by the app    #
##  - A development stub loader to make local runs and notebooks easier             #
##  - Guidance and comments on how to replace the stub with secure production       #                                       #                                          #                                   #
#####################################################################################

## Load all the libraries
import logging                                  # logging used across module for observability and debugging
from dataclasses import dataclass               # dataclass decorator for simple config containers
from typing import Any, Dict, Optional, Tuple   # typing helpers for function signatures

#=============================Logging Setup========================================================
# Azure Functions configures the root logger; we explicitly set level here to be explicit about expected verbosity.
logging.getLogger().setLevel(logging.INFO) # Ensure at least INFO logs are emitted
#=============================Data Class Module==========================================================
@dataclass
class AutomationConfig:
    """
    Configuration required for Azure Automation interactions.
    Keep automation-related values in a single typed object for clarity and testing.
    """
    subscription_id:str     # Azure subscription id used by SDK call
    resource_group: str     # target Azure resource group
    automation_account: str # name of the Automation Account to operate on
    location: str           # Azure region / location for resource operations
    hybrid_worker_group: str# Azure Hybrid Worker group Name 

@dataclass
class FoundryConfig:
    """
    Configuration required for Azure AI Foundry interactions.
    Encapsulate Foundry endpoint, agent IDs, and API version so callers are agnostic to source.
    """
    endpoint:str                # Base URL for Foundry API
    diagnostic_agent_id: str    # ID for diagnostic agent flows
    troubleshoot_agent_id: str  # ID for troubleshoot agent flows
    deployment: str             # Deployment name to invoke
    api_version: str            # API version string to include in requests

@dataclass
class AppConfig:
    """
    Top-level application config bundling environment, automation, and foundry settings.
    Pass a single AppConfig into services instead of multiple unrelated strings.
    """
    environment:str                 # Environment name (e.g., dev, prod) used for conditional logic
    automation: AutomationConfig    # Nested automation config
    foundry: FoundryConfig          # Nested foundry config

#=========================================Helpers: Setting===========================================
def read_config_dicts():
    """
    Development configuration stub that returns two dictionaries:  
      - Foundry_Variable: contains example/placeholder values required to talk to Azure AI Foundry  
      - Automation_Variable: contains example/placeholder values required to talk to Azure Automation  
  
    What this function is:  
      - A local development fallback that provides non-secret configuration required by the POC.  
      - Intentionally returns values inline so the remainder of the code can run without external secret stores.  
  
    Why this function exists:  
      - Makes it easy to run the notebook or function locally during development without provisioning Key Vault or other secret stores.  
      - Keeps a single place to list the configuration keys that production must supply via secure mechanisms.  
  
    Security and production notes:  
      - These values are NOT secrets in this stub, but some (like subscription IDs) are sensitive identifiers. Do NOT hard-code production secrets here.  
      - Before deploying to any non-development environment, replace this stub with a secure config loader:  
          1) Read non-secrets (e.g., region) from environment variables.  
          2) Read secrets from Azure Key Vault (or Akeyless) using DefaultAzureCredential.  
          3) Fail fast if required production values are missing.  
    Returns:  
      - tuple(foundry_dict, automation_dict)  
          foundry_dict: mapping of Foundry-related keys (Endpoint, Deployment, Agent IDs, API version)  
          automation_dict: mapping of Automation-related keys (subscription id, resource group, account, location)   
    """
    # Log that we're returning the development fallback dictionaries (helps trace behavior when running locally)  
    logging.info("Reading Configuration dictionaries.")    

    # Automation-related configuration values (development examples).  
    # NOTE: These are NOT secrets in this stub — they are plain configuration identifiers used for local testing. 
    Automation_Variable= {
        # Subscription id used by Azure SDKs (this is an identifier; treat as sensitive in production) 
        "AZ_SUBSCRIPTION_ID": "4c85c528-9da9-48ac-a5c3-41bd351728eb",  
        # Resource group containing your Automation Account  
        "AZ_RESOURCE_GROUP": "rg-fbntf-ais-swce-poc",
        # Automation account name (where runbooks are hosted)  
        "AZ_AUTOMATION_ACCOUNT": "aa-mbfin-ais-swce-poc",
        # Azure region / location (non-secret)   
        "LOCATION":"Sweden Central",
        # Azure Hybrid worker group name 
        "HYBRID_WORKER_GROUP":"Agentic_AI_POC_SCCM"
        } # End of automation variable dict.

    # Foundry-related configuration values (development examples).  
    # Keep keys consistent with what load_config_from_dict expects. 
    Foundry_Variable={
        # # Base endpoint for the Foundry project API
        "Endpoint": "https://aifoundry-rjteh-ais-swce-poc.services.ai.azure.com/api/projects/aifp-uqqnf-ais-swce-poc",
        "Model_Name": "gpt-5-mini",                                  # Model name used inside Foundry (informational).  
        "Deployment": "ITOA-Service_Desk-Agentic_AI_POC-gpt-5-mini", # Deployment identifier in Foundry.  
        "API_Version": "2024-12-01-preview",                         # Foundry API version.
        "DIAGNOSTIC_Agent_ID": "asst_MxWLoHuCHSwnPxyZfzUe2EOb",      # Diagnostic agent ID string.  
        "TROUBLESHOOT_Agent_ID": "asst_fP3eyPFbOQGjFvH7m909Kdi6"}    # Troubleshoot agent ID string.
    logging.info("Dictionaries loaded successfully.")                # Log completion. 
    return Foundry_Variable, Automation_Variable                     # Return both [Automation and Foundry] dictionaries to caller.  

#=========================================Helpers: Loading Configuration===========================================
def load_config_from_dict() ->Tuple[AppConfig, Dict[str, Any], Dict[str, Any]]:
    """
    Build an AppConfig dataclass from the development stub dictionaries. 
    What this function does:  
      - Calls read_config_dicts() to obtain development example configuration values.  
      - Maps those raw dictionary values into typed dataclasses:  
          - AutomationConfig: typed container for automation-related settings  
          - FoundryConfig: typed container for Foundry-related settings  
      - Returns a tuple containing (AppConfig, foundry_dict, automation_dict) so callers  
        can use both the strongly-typed config and the raw dictionaries for telemetry or SDK calls.  
  
    Why this behavior is used in the POC:  
      - Using typed dataclasses centralizes the shape of configuration values and improves readability and testability.  
      - Returning both typed and raw values provides backward compatibility with existing code paths that expect the raw dicts.  
  
    Production guidance:  
      - This loader is intentionally simple for development. For production:  
          - Replace read_config_dicts with a secure loader that reads secrets from Key Vault / Akeyless or environment variables.  
          - Validate required values and fail fast if critical configuration is missing.  
          - Avoid embedding subscription IDs or other sensitive identifiers directly in code.  
    Returns:  
      - config: AppConfig instance (with .automation and .foundry populated)  
      - foundry_dict: raw dictionary returned by read_config_dicts() containing Foundry keys  
      - automation_dict: raw dictionary returned by read_config_dicts() containing Automation keys  
    """

    # Explicitly mark environment (this stub indicates we're in development mode)  
    app_env= "dev"

    # Read the development dictionaries (foundry_dict first, automation_dict second) 
    foundry_dict, automation_dict= read_config_dicts()

    # Map automation dictionary values into the AutomationConfig dataclass.  
    # This enforces the expected keys and provides type hints to callers.  
    automation_cfg =AutomationConfig(
        subscription_id= automation_dict['AZ_SUBSCRIPTION_ID'],
        resource_group = automation_dict['AZ_RESOURCE_GROUP'],
        automation_account = automation_dict['AZ_AUTOMATION_ACCOUNT'],
        location = automation_dict['LOCATION'],
        hybrid_worker_group = automation_dict['HYBRID_WORKER_GROUP']
        )

    # Map foundry dictionary values into the FoundryConfig dataclass.  
    # Keep the keys aligned with what the rest of the code expects.
    foundry_cfg = FoundryConfig(
        endpoint= foundry_dict['Endpoint'],
        diagnostic_agent_id= foundry_dict['DIAGNOSTIC_Agent_ID'],
        troubleshoot_agent_id= foundry_dict['TROUBLESHOOT_Agent_ID'],
        deployment= foundry_dict['Deployment'],
        api_version= foundry_dict['API_Version']
        )

    # Bundle into the top-level AppConfig for a single object to pass around the application  
    config = AppConfig(environment= app_env, automation = automation_cfg, foundry = foundry_cfg)
    # Return the typed configuration plus the raw dicts for backward compatibility and telemetry use 
    return config, foundry_dict, automation_dict
