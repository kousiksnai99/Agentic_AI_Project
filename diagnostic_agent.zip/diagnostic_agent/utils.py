##################################################################################### 
## Project name : Agentic AI POC                                                    #
## Business owner , Team : ITOA                                                     #
## Notebook Author , Team: ITOA Project AI Team                                     #
## Date: 7th Dec 2026                                                               #
## Puprose of Notebook:                                                             #
## Centralized utilities used by the Agentic AI POC.                                #
##  - Extract default credentials                                                   #
##  - Stable JSON HTTP response factory for Azure Functions.                        #
##  - Robust request body validation returning typed objects.                       #
#####################################################################################


## Load all the libraries
import logging                                  # logging used across module for observability and debugging
from typing import Any, Dict, Optional, Tuple   # typing helpers for function signatures
import json                                     # json for serializing HTTP responses
from datetime import datetime
import time
import azure.functions as func                  # Azure Functions HttpResponse type used by utilities
# Auth / SDKs
from azure.identity import DefaultAzureCredential   # DefaultAzureCredential used for Azure auth

################ JSON RESPONSE FACTORY ###############  
def json_response(payload: Dict[str, Any], status: int =200) ->func.HttpResponse:
    """
    Returns a JSON-formatted HTTP response within consistent headers.
    Why:  
        Centralizes JSON response formatting so status codes, content-type  
        and serialization remain uniform across all code paths.  
    Args:  
        payload: Python object serializable to JSON.  
        status: HTTP status code.  
    Returns:  
        func.HttpResponse configured with application/json body. 

    Example: Success Response converts dictionary to json response
    - Input:
        payload ={
                    "message": "Operational Success",
                    "runbook_name": "runbook name"
                    }
        status =200

    - Output [HTTP Response]:
        status_code: 200
        Body:
            {
                "message":"Operational Success",
                "status": "runbook name"
            }
    """
    return func.HttpResponse(           # construct HttpResponse object
        body = json.dumps(payload),     # convert payload to JSON string
        status_code= status,            # HTTP status code
        mimetype ="application/json",   # content type  
        )

################ REQUEST VALIDATION ###############  
def validate_request_body(body: Dict[str, Any]) -> Tuple [str, bool, str]:
    """
    Validate and parse incoming HTTP JSON payload.
    Why:  
        Ensures the HTTP payload conforms to the expected contract early,  
        fails fast with clear errors, and returns parsed/typed values for  
        downstream business logic.  
    Expected Schema:
    {
        "issue" : "string, required",
        "execute": true/false, optional, default= true,
        "target_machine" : "string, required" ,
        "session_id" : "string, required"
    }
    Returns:  
        Tuple(issue, execute, target_machine, session_id, loggedin_username)  
    
    Example 1: [Success]
    - Input {json body}:
        {
            "issue": "Outlook Not Opening",
            "execute": "true,
            "target_machine": "LAPTOP-123"
            "session_id": "session_koreai"
        }
    - Output [Python tuple]:
        (
            "Outlook Not Opening",
            "true,
            "LAPTOP-123"
            "session_koreai"
            )
    
    Example 2: [Required fields missing]
    - Input {json body}:
        {
            "target_machine": "LAPTOP-123"
            "session_id": "session_koreai"
        }
    - Output [Exception Raised]:
        (
            ValueError: Missing required field: issue
            )    

    """
    issue = body.get("issue")                           # read issue field  
    if not isinstance(issue, str) or not issue.strip(): # validate issue presence and type  
        # raise for invalid
        raise ValueError("Field 'issue' is required and must be a non-empty string.")
    
    execute = bool(body.get("execute", True))   # default execute to True if not present  
    target_machine = body.get("target_machine", "").strip() or "UNSPECIFIED"    # If machine name is not specified the default machine name is taken [UNSPECIFIED]  
    session_id = body.get("session_id")     # session id comes from front end to easily track each requests
    loggedin_username=body.get("loggedin_username") # username required to verify if same user is logged in to the given machine
    
    if not isinstance(target_machine, str): # ensure target_machine is valid string [UNSPECIFIED is not valid]
        # raise for invalid  
        raise ValueError("Field 'target_machine' is required and must be a non-empty string.")
    if not isinstance(loggedin_username, str):  # ensure username is valid 
        # raise for invalid  
        raise ValueError("Field 'loggedin_username' is required and must be a non-empty string.")

    return issue.strip(), execute, target_machine, session_id, loggedin_username # return normalized values

################ AZURE CREDENTIAL###############
def get_default_credential() ->DefaultAzureCredential:
    """ 
    Create a Default Azure Credentialinstance suitable for functionapps.
    Why:  
        Use the managed identity or other available credentials in the  
        function environment, while explicitly excluding interactive/local  
        credentials so the function is predictable in cloud environments.  
    Returns:  
        An initialized DefaultAzureCredential. 
    """
    return DefaultAzureCredential(                      # create credential instance 
        exclude_interactive_browser_credential=True,    # disallow browser-based credential  
        exclude_visual_studio_code_credential=True,     # disallow VS Code credential  
        exclude_shared_token_cache_credential=True,     # disallow shared cache credential      
        exclude_powershell_credential=True              # disallow powershell credential  
        )