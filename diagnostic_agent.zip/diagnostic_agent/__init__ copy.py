##################################################################################### 
## Project name : Agentic AI POC                                                    #
## Business owner , Team : Data and AI                                              #
## Notebook Author , Team: POC Team                                                 #
## Date: 17th Nov 2025                                                              #
## Puprose of Notebook:                                                             #
## HTTPS-triggered Azure Function that:                                             #
##      1. Recieves and issue description from a caller [Service Desk/App].         #
##      2. Uses Azure AI Foundry diagnostic agent to identify the issue to an       #
##         Azure Automation Runbook.                                                #
##      3. Clones the runbook with additional metadata [eg. target machine] and     #
##         publish it for execution.                                                #
##      4. This published rubook is executed in target machine via SCCM.            #
##         This is done by running script by hybrid worker.                         #     
##      5. No hard-coded secrets: use Key Vault + DefaultAzureCredential            #
##         (managed identity)                                                       #
##      Runbook def:- These are powershell script hosted on azure automation that   # 
##                    are use to diagnose issues based on the KB article provided.  #                                                              
##      Hybrid Worker:- It is a component in Azure Automation that run automation   # 
##                    scripts (runbooks) directly on on-premises servers. It acts   #
##                    as an agent, pulling jobs from Azure Automation and executing # 
##                    them where the resources reside, overcoming limitations of    # 
##                    cloud-only workers.                                           #                                   #
#####################################################################################



# # Load all the libraries
import json                                     # json for serializing HTTP responses
import logging                                  # logging used across module for observability and debugging
import os
import uuid
from datetime import datetime
import time
from dataclasses import dataclass               # dataclass decorator for simple config containers
from typing import Any, Dict, Optional, Tuple   # typing helpers for function signatures

import azure.functions as func                  # Azure Functions HttpResponse type used by utilities
from azure.eventhub import EventHubProducerClient, EventData
from pydantic import BaseModel, ValidationError

# Auth / SDKs
from azure.identity import DefaultAzureCredential# DefaultAzureCredential used for Azure auth
from azure.mgmt.automation import AutomationClient


# Optional: Azure AI Projects
from azure.ai.projects import AIProjectClient
from azure.ai.agents.models import ListSortOrder
import requests

# Access the storage account
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError

from dotenv import load_dotenv
load_dotenv()


# Akeyless [Fetch Secrets]
import akeyless
from akeyless_cloud_id import CloudId


#=============================Logging Setup========================================================
# Azure Functions configures the root logger; we explicitly set level here to be explicit about expected verbosity.
logging.getLogger().setLevel(logging.INFO) # Ensure at least INFO logs are emitted

#=============================Data Class Module==========================================================
@dataclass
class AutomationConfig:
    """
    Configuration required for Azure Automation interactions.
    Keep automation-related values in a single typed object for clarity and testing.
    """
    subscription_id:str     # Azure subscription id used by SDK call
    resource_group: str     # target Azure resource group
    automation_account: str # name of the Automation Account to operate on
    location: str           # Azure region / location for resource operations

@dataclass
class FoundryConfig:
    """
    Configuration required for Azure AI Foundry interactions.
    Encapsulate Foundry endpoint, agent IDs, and API version so callers are agnostic to source.
    """
    endpoint:str                # Base URL for Foundry API
    diagnostic_agent_id: str    # ID for diagnostic agent flows
    troubleshoot_agent_id: str  # ID for troubleshoot agent flows
    deployment: str             # Deployment name to invoke
    api_version: str            # API version string to include in requests

@dataclass
class AppConfig:
    """
    Top-level application config bundling environment, automation, and foundry settings.
    Pass a single AppConfig into services instead of multiple unrelated strings.
    """
    environment:str                 # Environment name (e.g., dev, prod) used for conditional logic
    automation: AutomationConfig    # Nested automation config
    foundry: FoundryConfig          # Nested foundry config

#=========================================Helpers: Setting===========================================
def read_config_dicts():
    """
    Development stub: return dictionary examples for automation and foundry configuration.
    - Provide a single, discoverable place for example config keys while developing.  
    - IMPORTANT: These sample dictionaries are NOT secrets. In production replace with Key Vault,  
    environment variables, or a secure configuration service. 
    """
    logging.info("Reading Condiguration dictionaries.")     # Log start of config read

    # Automation-related configuration values (development examples).  
    # These are NOT secrets in this stub — they are plain configuration identifiers. 
    Automation_Variable= {
        # Hardcoded subscription id (should be secret-managed).
        "AZ_SUBSCRIPTION_ID": "4c85c528-9da9-48ac-a5c3-41bd351728eb",  
        # Hardcoded resource group name.  
        "AZ_RESOURCE_GROUP": "rg-fbntf-ais-swce-poc",
        # Hardcoded automation account name.  
        "AZ_AUTOMATION_ACCOUNT": "aa-mbfin-ais-swce-poc",
        # Hardcoded Azure region.  
        "LOCATION":"Sweden Central"
        } # End of automation variable dict.

    # Foundry-related configuration values (development examples).  
    # Keep keys that are required by load_config_from_config. 
    Foundry_Variable={
        # Foundry endpoint URL. 
        "Endpoint": "https://aifoundry-rjteh-ais-swce-poc.services.ai.azure.com/api/projects/aifp-uqqnf-ais-swce-poc",
        "Model_Name": "gpt-5-mini",                                  # Model name used inside Foundry (informational).  
        "Deployment": "ITOA-Service_Desk-Agentic_AI_POC-gpt-5-mini", # Deployment identifier in Foundry.  
        "API_Version": "2024-12-01-preview",                         # Foundry API version.
        "DIAGNOSTIC_Agent_ID": "asst_MxWLoHuCHSwnPxyZfzUe2EOb",      # Diagnostic agent ID string.  
        "TROUBLESHOOT_Agent_ID": "asst_fP3eyPFbOQGjFvH7m909Kdi6"}    # Troubleshoot agent ID string.
    logging.info("Dictionaries loaded successfully.")                # Log completion. 
    return Foundry_Variable, Automation_Variable                     # Return both [Automation and Foundry] dictionaries to caller.  

#=========================================Helpers: Loading Configuration===========================================
def load_config_from_dict() ->Tuple[AppConfig, Dict[str, Any], Dict[str, Any]]:
    """
    Build AppConfig from Akeyless dictionaries and environment.
    """
    app_env= "dev"
    foundry_dict, automation_dict= read_config_dicts()
    automation_cfg =AutomationConfig(
        subscription_id= automation_dict['AZ_SUBSCRIPTION_ID'],
        resource_group = automation_dict['AZ_RESOURCE_GROUP'],
        automation_account = automation_dict['AZ_AUTOMATION_ACCOUNT'],
        location = automation_dict['LOCATION']
        )
    foundry_cfg = FoundryConfig(
        endpoint= foundry_dict['Endpoint'],
        diagnostic_agent_id= foundry_dict['DIAGNOSTIC_Agent_ID'],
        troubleshoot_agent_id= foundry_dict['TROUBLESHOOT_Agent_ID'],
        deployment= foundry_dict['Deployment'],
        api_version= foundry_dict['API_Version']
        )
    config = AppConfig(environment= app_env, automation = automation_cfg, foundry = foundry_cfg)
    return config, foundry_dict, automation_dict

#==============================================Utilities========================================================

def json_response(payload: Dict[str, Any], status: int =200) ->func.HttpResponse:
    """
    Returns a JSON-formatted HTTP response within consistent headers.
    Why:  
        Centralizes JSON response formatting so status codes, content-type  
        and serialization remain uniform across all code paths.  
    Args:  
        payload: Python object serializable to JSON.  
        status: HTTP status code.  
    Returns:  
        func.HttpResponse configured with application/json body. 
    """
    return func.HttpResponse(           # construct HttpResponse object
        body = json.dumps(payload),     # convert payload to JSON string
        status_code= status,            # HTTP status code
        mimetype ="application/json",   # content type  
        )

def validate_request_body(body: Dict[str, Any]) -> Tuple [str, bool, str]:
    """
    Validate and parse incoming HTTP JSON payload.
    Why:  
        Ensures the HTTP payload conforms to the expected contract early,  
        fails fast with clear errors, and returns parsed/typed values for  
        downstream business logic.  
    Expected Schema:
    {
        "issue" : "string, required",
        "execute": true/false, optional, default= true,
        "target_machine" : "string, required" ,
        "session_id" : "string, required"
    }
    Returns:  
        Tuple(issue, execute, target_machine, session_id, loggedin_username)  

    """
    issue = body.get("issue")                           # read issue field  
    if not isinstance(issue, str) or not issue.strip(): # validate issue presence and type  
        # raise for invalid
        raise ValueError("Field 'issue' is required and must be a non-empty string.")
    
    execute = bool(body.get("execute", True))   # default execute to True if not present  
    target_machine = body.get("target_machine", "").strip() or "UNSPECIFIED"    # default if empty  
    session_id = body.get("session_id")     # session id comes from front end to easily track each requests
    loggedin_username=body.get("loggedin_username") # username required to verify if same user is logged in to the given machine
    
    if not isinstance(target_machine, str): # ensure target_machine is valid string 
        # raise for invalid  
        raise ValueError("Field 'target_machine' is required and must be a non-empty string.")
    if not isinstance(loggedin_username, str):  # ensure username is valid 
        # raise for invalid  
        raise ValueError("Field 'loggedin_username' is required and must be a non-empty string.")

    return issue.strip(), execute, target_machine, session_id, loggedin_username # return normalized values

def get_default_credential() ->DefaultAzureCredential:
    """ 
    Create a Default Azure Credentialinstance suitable for functionapps.
    Why:  
        Use the managed identity or other available credentials in the  
        function environment, while explicitly excluding interactive/local  
        credentials so the function is predictable in cloud environments.  
    Returns:  
        An initialized DefaultAzureCredential. 
    """
    return DefaultAzureCredential(                      # create credential instance 
        exclude_interactive_browser_credential=True,    # disallow browser-based credential  
        exclude_visual_studio_code_credential=True,     # disallow VS Code credential  
        exclude_shared_token_cache_credential=True,     # disallow shared cache credential      
        exclude_powershell_credential=True              # disallow powershell credential  
        )

#============================================Event Hub Logging==========================================
class EventHubLogger:
    """
    Simple wrapper for sending JSON events to Azure Event Hub using AAD
    authentication. No connection string is used.
    Why:  
        Centralize telemetry emission so errors, steps and durations can be  
        monitored externally. Using AAD auth (managed identity) avoids  
        embedding connection strings in code or config.  
    """
    def __init__(self, automation_dict: Dict[str, Any], credential: DefaultAzureCredential):
        namespace ="ehn-hrmqc-ais-swce-poc" # Event Hub namespace (hard-coded for POC)  
        name="evh-okvkc-ais-swce-poc"       # Event Hub name

        if not namespace or not name:       # check configuration presence
            logging.warning(
                "Event Hub namespace/name not configured. Event will not be sent."
                )                           # warn if missing
            self.producer: Optional[EventHubProducerClient] = None  # no producer available  
            return  # early return, logger will be no-op 
        
        try:
            # create the EventHubProducerClient with AAD credential 
            self.producer= EventHubProducerClient(      # instantiate producer  
                fully_qualified_namespace = namespace,  # set namespace
                eventhub_name = name,                   # set event hub name
                credential= credential                  # supply credential
            )
            logging.info("Event Hub Logger initialised for hub '%s'.", name)    # success log
        except Exception:
            logging.exception("Failed to initialise Eventhub producer client.") # log exception 
            self.producer=None                                                  # mark producer as unavailable
    
    def send_event(self, event: Dict[str, Any]) -> None:
        """
        Send a single JSON event to Event Hub. Failure is logged but doesn't
        break the main flow.
        Why:  
            Telemetry should not break the main processing flow. This wrapper  
            ensures non-fatal telemetry failures are recorded but ignored. 
        """
        if not self.producer:   # if no producer configured, do nothing 
            return              # no-op when telemetry not configured 
        
        try:
            paylod = json.dumps(event)      # serialize event to JSON string  
            event_data =EventData(payload)  # wrap payload into EventData  
            with self.producer:             # context-manage the producer
                batch = self.producer.create_batch()    # create an event batch  
                batch.add(event_data)                   # add the serialized event
                self.producer.send_batch(batch)         # send the batch 
            logging.info("Event sent to Event Hub: %s", event.get("event_type"))    # log success
        except Exception:
            logging.exception("Failed to send event to eventhub.")  # log but do not raise any issue  

#==============================================AZURE AUTOMATION===================================
class AzureautomationService:
    """
    Wrapper around azure automation operations (Runbook CRUD, REST content).
    Why:  
        Encapsulate Azure Automation interactions to keep API calls and  
        authentication logic in one place, making higher-level orchestration  
        code easier to read and test. 
    """

    def __init__(self, config: AutomationConfig, credential: DefaultAzureCredential):
        self.config=config          # store automation config for later calls 
        self.credential=credential  # store credential for token acquisition  
        self.client = AutomationClient(credential, config.subscription_id)  # create Azure Automation SDK client  
     
    def get_rest_token(self) -> str:
        """
        Acquire an access token for Azure Resource Manager using managed identity.  
        Why:  
            Some REST endpoints (raw content / output) are only available via  
            ARM REST and not via the high-level SDK; a bearer token is needed.  
        Returns:  
            string bearer token valid for one hour
        """
        token = self.credential.get_token("https://management.azure.com/.default").token    # get token string  
        
        # return the token to be used in Authorization headers for REST calls  
        return token  # token valid for a limited period (usually 1 hour)   
                                               

    def fetch_runbook_content(self, runbook_name: str) -> Optional[str]:
        """
        Fetch runbook content directly from Azure via REST API.
        Why:  
            The SDK may not expose raw runbook script content consistently  
            across regions/versions; fetching via ARM REST ensures we get the  
            raw content bytes and can annotate or clone it.  
        Returns:  
            runbook script as string or None if not found/error.
        """
        token=self.get_rest_token() # acquire a REST bearer token for ARM calls (reuses managed identity)
        
        # build the ARM REST URL referencing subscription, resource group, automation account and runbook   
        url = (
            f"https://management.azure.com/subscriptions/{self.config.subscription_id}"
            f"/resourceGroups/{self.config.resource_group}"
            f"/providers/Microsoft.Automation/automationAccounts/{self.config.automation_account}"
            f"/runbooks/{runbook_name}/content?api-version=2024-10-23"
            )   # REST endpoint for runbook content (specific api-version ensures stability)  
        
        # prepare headers including authorization and an accept header for binary/octet-stream responses      
        headers = {
            "Authorization": f"Bearer {token}",     # supply bearer token for ARM auth
            "Accept": "application/octet-stream"    # request raw content bytes  
            }
        # perform HTTP GET to download the runbook content
        response = requests.get(url, headers=headers)    # call ARM REST to retrieve content  
        
        # if response is OK then decode bytes to UTF-8 string and return  
        if response.status_code == 200:
            logging.info("Fetched content for runbook '%s'.", runbook_name) # log success with runbook name 
            return response.content.decode("utf-8", errors="ignore")        # return decoded script text  
        
        # log a warning including status code and text if retrieval failed  
        logging.warning(
            "Failed to fetch content for runbook '%s'. status: %s, Bodr: %s",
            runbook_name,
            response.status_code,
            response.text,
            )   # record details to help troubleshoot REST failures  
        
        # return None for callers to handle absence of content 
        return None

    def create_or_update_runbook(self, runbook_name: str, runbook_content: str) -> None:
        """
        Create or update a runbook, upload its content, publish it, and start execution on hybrid worker.  
  
        Why:  
        - Ensures metadata exists, uploads the script to the runbook draft, publishes it,  
          then triggers the runbook on the specified Hybrid Worker Group.  
        - Encapsulates all steps so higher-level code only needs to call this single method.  
        Returns:  
        - tuple(job_name, job.job_id) so caller can subsequently query job outputs if needed. 
        """
        # log start of create/update operation so execution can be traced  
        logging.info("Creating or updating runbook '%s'.", runbook_name)     # helpful for tracing and monitoring

        # 1. Create or Update Runbook metadata (ensures runbook exists) 
        runbook = self.client.runbook.create_or_update(
            resource_group_name = self.config.resource_group,           # RG containing automation account 
            automation_account_name= self.config.automation_account,    # automation account name  
            runbook_name = runbook_name,                                # requested runbook name 
            parameters={                            # metadata properties for the runbook  
                "location": self.config.location,   # set location for runbook resource                           
                "properties" : {
                    "runbookType": "PowerShell",    # declare runbook scripting language
                    "logProgress": False,           # disable verbose progress logging (configurable) 
                    "logVerbose": False,            # disable verbose logs to reduce noise 
                }
            }
        )  # create_or_update ensures resource exists and returns metadata  

        # log resource id returned by SDK so we can correlate resources in logs             
        logging.info(
            "Runbook metadata ensured for '%s'.Resource ID: %s",
            runbook_name,
            runbook.id
            )       # runbook.id is helpful for debugging or audit 
      
        # 2. Upload content to the Draft of the runbook (replace draft content)  
        draft_poller = self.client.runbook_draft.begin_replace_content(
            resource_group_name= self.config.resource_group,            # RG name 
            automation_account_name=self.config.automation_account,     # automation account name  
            runbook_name = runbook_name,                                # name of runbook to update draft for  
            runbook_content = runbook_content                           # actual script content to upload  
        )   # begin_replace_content returns a poller we must wait on  


        # wait for the draft content upload to complete (blocking call)  
        draft_poller.result()       # ensures the draft content upload is finished before moving on  

        # log success of content upload for observability 
        logging.info("Runbook draft content uploaded for'%s'", runbook_name)    # indicate content update finished 


        # 3. Publish the runbook so that it is available for execution (draft -> published) 
        publish_poller=self.client.runbook.begin_publish(
            resource_group_name=self.config.resource_group,         # RG name for publish call  
            automation_account_name=self.config.automation_account, # automation account  
            runbook_name = runbook_name,                            # which runbook to publish 
        )   # begin_publish returns a poller 

        # wait for publish operation to finish so subsequent run uses published version
        publish_poller.result()
        # log that the runbook is published for monitoring 
        logging.info("Runbook '%s' published successfully.", runbook_name)  # published runbook is now runnable

        # 4. Execute the runbook on a Hybrid Worker Group (used to run scripts on-premises) 
        logging.info("Starting runbook execution on Hybrid Worker Group: %s", runbook_name) # informational log 
        
        # prepare a job name to create a job resource (helps with idempotency and tracking)
        job_name = f"job_{runbook_name}"

        # create the job resource which triggers the runbook run on target Hybrid Workers 
        job = self.client.job.create(
            resource_group_name=self.config.resource_group,         # RG containing automation account 
            automation_account_name=self.config.automation_account, # automation account name
            job_name=job_name,                                      # job name to create
            parameters={
                "properties": {
                    "runbook": {"name": runbook_name},              # instruct job to run this runbook 
                    "parameters": {},                               # pass any runbook params (empty here) 
                    "runOn": "Agentic_AI_POC_SCCM"                  # Hybrid Worker Group name (target environment) 
                }
            }
        )                                                           # job creation triggers execution on hybrid worker group specified  

        # log job id returned by SDK so we can refer to it for output retrieval
        logging.info(
            "Runbook execution started on Hybrid Worker Group. Job ID = %s",
            job.id
        )   # job.id uniquely identifies this runbook execution instance  

        # return the job name and job id so caller can poll for outputs or return to clients
        return job_name, job.job_id     # provide identifiers to track and fetch output later  

#============================================USER COMPARISON============================================
    def test_user_comparison(self,tevacorp_user_id):
        # helper mapping to convert certain internal usernames to a test-corp mapping
        # This was done because teams is in teva corp while user machine is in test domain
        # It is done to verify if both users are same.
        tevacorp_testcorp_comparison_dictionary = {
            "PRA01":"TestPrashanth",
            "ARR02": "TestArchudan",
            "NRODRIGUES": "TestNatasha",
            "RSRINIVASA02": "TestRakesh",
            "NHADIMANI": "TestNidhi",
            "MMENJIVA": "TestMaynor",
            "MAADAMS": "TestMalcolm",
            "BWARNER": "TestBrian",
            "SROWDEN": "TestSteven",
            "AATAK": "TestAleyna",
            "MYENI": "TestMert",
            "ASHEINFELD": "TestAviram",
            "EGILBOA01": "TestEli",
            "CSALGADO02": "TestCassandra",
            "BAGUILAR": "TestBetsabe",
            "HSHAH11": "TestHarsh",
            "KER01":"GLSDUser1",
            "VPRAKASH07":"GLSDUser1",
            "KDAS":"GLSDUser1",
            "VJADHAV08":"GLSDUser1",
            "LSOJIC":"GLSDUser1",
            "KSNAI":"GLSDUser1",            
        }   # mapping of known usernames for test corp substitution
        
        # check if provided user id (uppercased) exists in mapping keys and return mapped name or uppercase original 
        if tevacorp_user_id.upper() in tevacorp_testcorp_comparison_dictionary.keys():
            return tevacorp_testcorp_comparison_dictionary[tevacorp_user_id.upper()]    # return mapped test name
             
        else:
            return tevacorp_user_id.upper() # default: return uppercase original for consistency  

########################FUNCTION: get_output_by_runbook_name######################
    def get_runbook_output(self,job_name: str, job_id: str) -> str:
        """
        Fetch Azure Automation runbook output using JOB ID.
        Works for all regions including Sweden Central.
        Why:  
        - Some job outputs are only available via the ARM job output endpoint.  
        - Polling here centralizes wait/retry logic and abstracts the REST call details.  
  
        Returns:  
        - job output text on success, or None if output could not be fetched.  
        """

        # continuously poll the job status until it's completed, failed, or stopped 
        while True:
            job_status = self.client.job.get(
                resource_group_name=self.config.resource_group,         # RG for job  
                automation_account_name=self.config.automation_account, # automation account  
                job_name=job_name                                       # job name used to get job status 
            ).status    # read status property returned by SDK 

            # break out of the loop once job reaches a terminal state (completed/failed/stopped)  
            if job_status.lower() in ["completed", "failed","stopped"]:
                break        # exit polling when job ended
            
            # otherwise wait a short interval before polling again to avoid tight-looping  
            time.sleep(5)   # sleep to throttle polling and avoid rate-limits  

        # after completion, acquire REST token for accessing job output endpoint
        token=self.get_rest_token() # get bearer token for ARM REST output call  
        
        # build the job output ARM REST URL using subscription and job id  
        output_url = (
            f"https://management.azure.com/subscriptions/{self.config.subscription_id}"
            f"/resourceGroups/{self.config.resource_group}"
            f"/providers/Microsoft.Automation/automationAccounts/{self.config.automation_account}"
            f"/jobs/{job_id}/output?api-version=2023-11-01"
        )   # job output endpoint (api-version selected to be compatible)  

        # prepare headers for REST call, include authorization and accept octet-stream 
        headers = {
            "Authorization": f"Bearer {token}",     # supply bearer token for ARM auth
            "Accept": "application/octet-stream"    # expect raw output  
            }
            # perform the GET request to retrieve job output from ARM 
        
        response = requests.get(output_url, headers=headers)    # call ARM to fetch job output 

        # if successful, log and return text body  
        if response.status_code == 200:
            logging.info("Fetched output for the job '%s'.", job_id)    # log when output retrieval succeeds 
            return response.text                                        # return output content as text for caller consumption  

        # if not successful, log a warning with status and body to ease troubleshooting 
        logging.warning(
            "Failed to fetch the output '%s'. status: %s, Bodr: %s",
            job_id,
            response.status_code,
            response.text,
            )   # capture REST failure details in logs
        
        # return None so callers can detect missing output
        return None

    def clone_runbook_with_metadata(self, source_runbook_name: str, system_name: str, issue_text: str, environment: str, session_id: str, loggedin_username: str) -> str:
        """
        Creates a new runbook by cloning an existing runbook's content and
        adding contextual metadata as a header comment.
        Why:  
        - We need to run diagnostics tied to a specific target machine and session.  
        - Cloning allows us to annotate the runbook with metadata (device name, session id, username)  
          that the script can use at runtime, while preserving the original runbook.  
        - This method centralizes fetch->annotate->publish->execute flow so callers only provide inputs.  
  
        Returns:  
        - (new_runbook_name, job_name, job_id) so caller can present identifiers and poll outputs.  
        """

        # fetch the original runbook content via REST; if None raise to be handled by caller  
        original_content=  self.fetch_runbook_content(source_runbook_name)  # get the existing runbook script  

        if original_content is None:
            raise ValueError(f"No content returned for runbook '{source_runbook_name}'")    # fail fast if missing 

        # create a timestamp to aid in naming and traceability (not currently used in name but useful if needed) 
        timestamp= datetime.utcnow().strftime("%Y%m%d_%H%M%S")  # timestamp useful for unique naming or logs  
        
        # small convenience prefix (kept for potential future use in script body) 
        source_script = f"$SystemName:{system_name}\n"      # include system name line for script context (unused variable ok) 
        
        # construct a new runbook name combining source name, target system and session id for uniqueness and readability 
        new_runbook_name = f"{source_runbook_name}_{system_name}_{session_id}"  # ensures clone is identifiable  


        # header_block contains lines to prepend to the original script to provide runtime metadata and setup
        header_block = [
            f"# Generated by Agentic Automation Team- ",    # comment identifying auto-generated script provenance  
            f"$ScriptName = '{new_runbook_name}'",          # set runtime variable with script name (PowerShell)  
            f"$DeviceName = '{system_name}' ",              # set runtime variable with device name  
            f'$Loggedin_Username = "{self.test_user_comparison(loggedin_username)}" ',  # set username variable (mapped)  
            f"Import-Module ($Env:SMS_ADMIN_UI_PATH.Substring(0,$Env:SMS_ADMIN_UI_PATH.Length-5) + '\ConfigurationManager.psd1')",  # import SCCM module using environment path  
            f"cd CBL:",                             # change directory to expected working dir (CBL:)  
            f"# Step 1: Inline script content",     # marker for where original content starts  
            f"$scriptText = @'",                    # begin here-doc style multiline string in PS if used downstream  
            f'$Loggedin_Username = "{self.test_user_comparison(loggedin_username)}" ',   # repeat username inside script text block for visibility  
            ]       # header_block is a list of strings to join and prepend to original script content  
        
        # join the header lines and append the original content to produce the annotated script to upload
        annotated_content = "\n".join(header_block) + original_content   # final script content to upload into new runbook  

        # create or update the cloned runbook, upload content, publish it, and trigger a job; returns job identifiers  
        job_name, job_id=self.create_or_update_runbook(new_runbook_name, annotated_content)        # publish & run clone 
        
        # return the new runbook name plus job identifiers for caller use  
        return new_runbook_name,job_name,job_id # return triple: cloned name, job name and job id  

#=============================================Azure AI Foundry==========================================

class FoundryAgentService:
    """
    Service wrapper for interacting with Azure AI Foundry agents.  
  
    Why this class exists:  
    - Separates Foundry-specific API usage from orchestration code so callers can  
      ask "which runbook should I run?" without needing Foundry SDK details.  
    - Centralizes request/response and minimal retry/inspection logic so we can  
      maintain and test agent resolution in one place.  
  
    High-level behavior:  
    - __init__: initialize AIProjectClient and pre-load the diagnostic agent reference.  
    - resolve_runbook_from_issue: send the issue text to the diagnostic agent,  
      run the agent, read back messages and attempt to resolve the runbook name.  
  
    Returns:  
    - resolve_runbook_from_issue returns a tuple (resolved_runbook_name, Resolve_Logger)  
      where resolved_runbook_name may be None if the agent failed to resolve a runbook,  
      and Resolve_Logger is a dictionary containing timestamps and minimal telemetry for debugging. 
    """


    def __init__(self, config: FoundryConfig, credential: DefaultAzureCredential):
        self.config = config    # store Foundry configuration so methods can access endpoint, agent ids, etc. and keep config for reuse
        
        # create the AIProjectClient with the given endpoint and credential to access Foundry Project APIs  
        # create client used to interact with Foundry
        self.project = AIProjectClient(endpoint= config.endpoint, credential=credential)    # instantiate Foundry client


         # pre-fetch the diagnostic agent object referenced by id to avoid repeated lookups at runtime  
         # cache agent reference for efficiency  
        self.agent = self.project.agents.get_agent(self.config.diagnostic_agent_id) # get agent metadata/object by id  
    
    
    def resolve_runbook_from_issue(self, issue_text: str) ->Optional[str]:
        """
        Sends the issue to the diagnostic agent and expects a final message
        that contains the resolved runbook name.
        Why:  
        - We rely on Foundry's diagnostic agent to map free-text issues to the canonical runbook name.  
        - Returning a structured Resolve_Logger alongside the result helps with observability and post-mortem debugging.  
  
        Args:  
        - issue_text: the free-text issue description supplied by caller.  
  
        Returns:  
        - (resolved_runbook_name, Resolve_Logger)  
          resolved_runbook_name: str or None if no runbook was identified  
          Resolve_Logger: dict containing timestamps and stages for visibility into the Foundry call lifecycle  
        """
        Resolve_Logger={}   # initialize a dictionary to capture timestamps and stages for later debugging

        # create telemetry container  
        logging.info("Sending issue to Foundry diagnostic agent.")          # log intent for observability
        
        # notify that resolution is starting  
        Resolve_Logger['Thread_Start']=datetime.utcnow().isoformat() +'Z'   # mark when we begin thread creation  # timestamp start 
        thread = self.project.agents.threads.create()                       # create a new conversation thread so messages and runs are isolated
        Resolve_Logger['Thread_End']=datetime.utcnow().isoformat() +'Z'     # record when thread creation finished  # timestamp end 
        Resolve_Logger['Message_Start']=datetime.utcnow().isoformat() +'Z'  # record when we start sending the user's message  # timestamp  
        
        self.project.agents.messages.create(        # post the user's issue text as a message in the thread  # submit message  
            thread_id=thread.id,                    # associate message to created thread  # reference thread  
            role='user',                            # mark message role as 'user' so agent knows it's user input  # set role 
            content=issue_text                      # the actual issue text we want the agent to process  # message content
        )
        Resolve_Logger['Message_End']=datetime.utcnow().isoformat() +'Z'    # record completion of message creation  # timestamp  
        Resolve_Logger['Run_Start']=datetime.utcnow().isoformat() +'Z'      # mark when we request agent processing to start  # timestamp
        run = self.project.agents.runs.create_and_process(                  # instruct Foundry to create and execute a run for the thread  # trigger run  
            thread_id=thread.id,                                            # run against the thread we created  # reference thread  
            agent_id=self.agent.id,                                         # run the configured diagnostic agent  # choose agent  
            )
        Resolve_Logger['Run_End']=datetime.utcnow().isoformat() +'Z'        # record when the run request finished  # timestamp  

        if run.status == "failed":                                          # check if the run failed according to Foundry  # inspect run status  
            logging.error("Foundry run failed. Error: %s")                  # log an error to help diagnostics (no specific error string available here)  # log failure  
            return None                                                     # return None for runbook name, but include Resolve_Logger for debugging  # return failure
        
        Resolve_Logger['Order_Start']=datetime.utcnow().isoformat() +'Z'    # record when we start listing messages  # timestamp  
        messages = self.project.agents.messages.list(                       # fetch all messages for the thread so we can inspect agent responses  # read messages  
            thread_id = thread.id,                                          # limit messages to our thread  # reference thread  
            order = ListSortOrder.ASCENDING,                                # request messages in ascending order to read from earliest to latest  # ordering
        )


        Resolve_Logger['Order_End']=datetime.utcnow().isoformat() +'Z'      # mark when message list retrieval finished  # timestamp 
        resolved_runbook_name: Optional[str] = None                         # initialize result variable to None; will set if agent returned a candidate  # prepare result  
        Resolve_Logger['Msg_Read_Start']=datetime.utcnow().isoformat() +'Z' # timestamp for starting message inspection  # timestamp  
        for message in messages:                                            # iterate messages to find text responses from the agent  # iterate responses 
            if not message.text_messages:                                   # skip messages that don't contain text payloads  # guard for empty text  
                continue                                                    # continue to next message if no text messages present  # skip  
            resolved_runbook_name= message.text_messages[-1].text.value     # read the last text chunk's value as the candidate runbook name  # extract runbook 
        Resolve_Logger['Msg_Read_End']=datetime.utcnow().isoformat() +'Z'   # mark message inspection end time  # timestamp  
        
        # if agent returned some text, log that we resolved a candidate runbook name  # check result 
        if resolved_runbook_name:           
            # write informational log with resolved runbook name  # log resolved runbook 
            logging.info(
                "Foundry diagnostic agent resolved runbook '%s'.",
                resolved_runbook_name,
            )
        # if resolution failed, log a warning so operators can follow up  # handle no result  
        else:
            logging.warning(    # warn that no runbook was resolved by agent  # log missing result  
                "Foundry diagnostic agent did not return a runbook name."
            )
        
        # return the candidate runbook name (or None) along with the logger dict  # return tuple  
        return resolved_runbook_name, Resolve_Logger

#==============================================Azure Function Entry======================================

def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    HTTP-triggered Azure Function entry point.
    Responsibilities:  
    - Validate and parse incoming request JSON payload.  
    - Load configuration and authenticate using managed identity.  
    - Use Foundry to resolve which Automation runbook should run for the issue text.  
    - Clone, annotate, publish and run the resolved runbook on the Hybrid Worker group.  
    - Emit telemetry events and return a structured JSON response including timing and resolution logs.  
  
    Why:  
    - This function orchestrates the end-to-end flow from issue text to automated diagnostics,  
      while avoiding embedded secrets and centralizing telemetry for monitoring.  
  
    Returns:  
    - func.HttpResponse with JSON body describing success/failure and identifiers for tracking. 
    """

    # get external correlation id or generate one for tracing  # correlation for logs
    correlation_id = req.headers.get("x-correlation-id", str(uuid.uuid4()))

    # log incoming request and correlation id  # entry log  
    logging.info("Request recieved for Agentic Automationfunction. CORRELATIONID = %s", correlation_id)

    # prepare dictionary to collect stage timestamps for response debugging  # timing telemetry container
    time_logger={}
    
    try:# top-level try to catch unexpected errors and return a 500 with details  # guard for unexpected exceptions
        # 1. Parse JSON body
        try:    # nested try to give a clearer 400 error for invalid JSON  # handle bad JSON specifically 
            time_logger['JSON_Parser_Start']=datetime.utcnow().isoformat() +'Z' # record JSON parse start time  # timestamp  
            request_body = req.get_json()   # parse JSON payload from the HttpRequest object  # read JSON body  
            time_logger['JSON_Parser_End']=datetime.utcnow().isoformat() +'Z'   # record JSON parse end time  # timestamp  
        
        except ValueError:  # raised by get_json if payload is not valid JSON  # catch invalid JSON
            logging.warning("Invalid JSON in request body.")    # log a warning to indicate client error  # warn client  
            
            return json_response(   # return 400 with a helpful message so clients can correct payload  # respond with bad request 
                {"Success": False, "error": {"message":"Invalid JSOn payload."}},
                status = 400
            )
        
        # 2. Validate Schema
        try:    # schema validation isolated so we can return a 400 for contract violations  # validate contract 
            
            # timestamp start for validation  # timestamp  
            time_logger['Schema_Validation_Start']=datetime.utcnow().isoformat() +'Z' 
            
            # validate and normalize fields  # parse and validate    
            issue, execute, target_machine, session_id, loggedin_username = validate_request_body(request_body)
            
            # timestamp end for validation  # timestamp  
            time_logger['Schema_Validation_End']=datetime.utcnow().isoformat() +'Z'

        # validation errors are surfaced as ValueError from helper  
        # catch validation errors      
        except ValueError as value_error:
            # log validation failure details  
            # warn validation 
            logging.warning("Request validation failed: %s", value_error)
            return json_response(
                # return 400 describing which field failed validation  
                # respond with validation error  
                {"Success": False, "error":{"message": str(value_error)}},
                status= 400
            )

        #3. Load configuration [Env, Automation, Foundry]

        # handle config load errors distinctly so we can return a 500 with context  
        # load configuration
        try:
            # record config load start time  
            # timestamp  
            time_logger['Config_Start']=datetime.utcnow().isoformat() +'Z'
            
            # build AppConfig and supportive dicts (dev stub)  
            # load config  
            config, foundey_dict, automation_dict = load_config_from_dict()

            # record config load end time  
            # timestamp  
            time_logger['Config_End']=datetime.utcnow().isoformat() +'Z'

        # capture environment/config related exceptions  
        # catch config errors    
        except EnvironmentError as environment_error:
            # log full stack for ops to inspect  
            # error log  
            logging.exception("Configuration loading failed.")
            return json_response(
                {"Success":False, 
                "error":{
                    "message":f"Configuration error.",
                    "details": str(environment_error)
                    }
                },
                status = 500
            )

        # obtain DefaultAzureCredential to use managed identity for all SDK calls  
        # get managed identity credential  
        credential = get_default_credential()

        # instantiate automation helper with config and credential  
        # create automation service  
        automation_service = AzureautomationService(config.automation, credential)

        # instantiate foundry helper to resolve runbooks  
        # create foundry service
        foundry_service = FoundryAgentService(config.foundry, credential)

        # telemetry helper to emit events to Event Hub via AAD  
        # create event logger 
        event_logger= EventHubLogger(automation_dict, credential)
        
        # emit an event indicating we received an issue (non-blocking by design)  
        # send telemetry event 
        event_logger.send_event(
            {
                "event_type": "issue recieved",     # simple event type used for downstream filtering  # event type  
                "correlation_id": correlation_id,   # correlate to request for tracing across systems  # correlation id
                "environment": config.environment,  # include environment so metrics can be segmented  # env tag  
                "target_machine": target_machine,   # include target machine for context  # target context  
                "execute": execute,                 # include whether caller asked to execute or just simulate  # execution flag 
                "timestamp_utc": datetime.utcnow().isoformat() +'Z',    # timestamp for the event  # event timestamp
            }
        )

        #4. Resolve runbook using AI Foundry Agent

        # call foundry and get potential runbook name + logger  
        # resolve runbook
        runbook_name, Resolve_Logger = foundry_service.resolve_runbook_from_issue(issue)
        
        # if foundry couldn't map issue to runbook, emit event and return 404 so user can escalate  
        # handle unresolved mapping  
        if not runbook_name:
            # log the resolution failure event for monitoring and alerting  
            # telemetry
            event_logger.send_event(
                {
                    "event_type": "Runbook Resolution Failed",  # event type for failed resolution  # type  
                    "correlation_id": correlation_id,           # include correlation id so this event ties back to request  # correlation id
                    "environment": config.environment,          # environment context  # env  
                    "timestamp_utc": datetime.utcnow().isoformat() +'Z',    # when failure happened  # timestamp
                }
            )
            # return 404 to indicate we couldn't find an appropriate runbook  
            # respond not found 
            return json_response(
                {"Success": False, "error": {"message":(
                    "No Runbook could be resolved for the given issue.",
                    "Please contact the agentic AI POC team."
                    )}},
                    status =404
            )

        #5. Execute path: Clone runbook with metadata, publish and Run

        # attempt clone/publish/run and surface any exception as a 502 so caller knows it was downstream failure  
        # clone & run
        try:
            # clone runbook with context and trigger execution  
            # create clone & job
            cloned_name, job_name, job_id = automation_service.clone_runbook_with_metadata(
                source_runbook_name= runbook_name,  # name returned by Foundry  # original runbook name  
                system_name = target_machine,       # target device for diagnostics  # target machine  
                issue_text = issue,                 # original issue text for potential use inside runbook  # issue 
                environment = config.environment,   # environment string for script annotation  # env  
                session_id=session_id,              # session id used to make cloned name unique  # session id  
                loggedin_username=loggedin_username # username for runtime context inside script  # logged-in user  
            )
        
        # catch any exception produced while cloning/publishing/executing  
        # handle clone errors  
        except Exception as unknown_exception:
            logging.exception("Runbook cloning failed.")    # log full stack trace for operations to diagnose  # error log  
            event_logger.send_event(    # emit telemetry event describing the clone failure for alerting  # telemetry
                {
                    "event_type": "Runbook Clone Failed",   # event type name  # type  
                    "correlation_id": correlation_id,       # tie event back to request  # correlation id  
                    "environment": config.environment,      # environment context  # env  
                    "Original Runbook": runbook_name,       # original runbook name that we attempted to clone  # original runbook 
                    "error": str(unknown_exception),        # include exception message for quick triage (avoid secrets)  # error details
                    "timestamp_utc": datetime.utcnow().isoformat() +'Z',    # timestamp for the event  # timestamp
                }
            )

            # return 502 indicating an upstream dependency failed (automation service)  
            # respond bad gateway  
            return json_response(   
                {"Success": False,
                "error":{
                    "message":"Runbook cloning or publishing failed.",
                    "details": str(unknown_exception)
                    }
                },
                status = 502
            )

        # informational log confirming clone succeeded  # success log  
        logging.info("Runbook cloned successfully: %s", cloned_name)
        
        # emit telemetry indicating the clone was successful and include relevant identifiers  
        # telemetry
        event_logger.send_event(
            {
                "event_type": "Runbook cloned successfully",    # event type  # type  
                "correlation_id": correlation_id,               # correlation id for tracing  # correlation  
                "environment": config.environment,              # environment context  # env  
                "Original Runbook": runbook_name,               # original runbook name  # original  
                "Cloned_Runbook": cloned_name,                  # cloned runbook name  # clone  
                "target_machine": target_machine,               # target device  # target  
                "timestamp_utc": datetime.utcnow().isoformat() +'Z',    # event timestamp  # timestamp
            }
        )

        # optional: fetch runbook output if caller needs it  # optional fetch

        # return 200 with structured information about what was executed and telemetry for debugging  
        # success response  
        return json_response(
            {
                "Success": True,                        # indicate success to the caller  # result  
                "original_runbook_name": runbook_name,  # the runbook name found by Foundry  # original  
                "cloned_runbook_name": cloned_name,     # the cloned runbook that was created  # clone  
                "job_name":job_name,                    # job name created in Automation (useful for polling)  # job name 
                "job_id": job_id,                       # job id (system identifier for the run)  # job id  
                "executed": True,                       # whether the run was started  # executed flag  
                "target_machine": target_machine,       # target device for executed runbook  # target  
                "environment": config.environment,      # environment string used by the function  # env  
                "message": (                            # user-friendly message explaining next steps  # message  
                    f"Diagnosis process have been triggered and it may take few minutes."
                    ),
                "Time_Logger":time_logger,              # include timing telemetry to help with performance debugging  # timings  
                "Resolution_Logger":Resolve_Logger      # include Foundry resolution telemetry for post-mortem analysis  # foundry logs  
            },
            status = 200
        )

    # catch any top-level unhandled exception to avoid leaking stack traces to clients  
    # safety net  
    except Exception as unhandled_exception:
        # log full stack locally for operators  # error log  
        logging.exception("Unhandled exception in agentic automation function.")
        
        # return a 500 to indicate server error and include the exception message for support  
        # server error response  
        return json_response(
            {
                "Success": False,
                "error":{
                    "message": "Unhandled Server error. Please contact the automation team.",
                    "details": str(unhandled_exception),
                }
            },
            status= 500
        )
