import os
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential
from azure.ai.agents.models import ListSortOrder
from servicenow_api import ServiceNowAPI
from config_manager import ConfigManager
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class TicketingAgent:
    def __init__(self, config_file: str = "config.json"):
        self.config = ConfigManager(config_file)
        azure_config = self.config.get_azure_config()
        
        # Get Azure configuration from env or config
        endpoint = os.getenv('AZURE_PROJECT_ENDPOINT') or azure_config.get('project_endpoint')
        agent_id = os.getenv('AZURE_AGENT_ID') or azure_config.get('agent_id')
        
        self.azure_available = False
        self.project = None
        self.agent = None
        
        # Try to initialize Azure AI Project Client
        try:
            self.project = AIProjectClient(
                credential=DefaultAzureCredential(),
                endpoint=endpoint
            )
            # Test the connection
            self.agent = self.project.agents.get_agent(agent_id)
            self.azure_available = True
            print(self.config.get_message("initialization", "success"))
            print(self.config.get_message("initialization", "azure_endpoint", endpoint=endpoint))
            print(self.config.get_message("initialization", "agent_id", agent_id=agent_id))
        except Exception as e:
            print(f"Azure AI not available: {str(e)}")
            print("Running in ServiceNow-only mode...")
            self.azure_available = False
        
        # Initialize ServiceNow API
        self.servicenow = ServiceNowAPI(config_file)
        
        if not self.azure_available:
            print("Ticketing Agent initialized in ServiceNow-only mode")
            print("You can still create, update, and manage ServiceNow tickets")

    def chat(self, user_message: str):
        """Send a message to the agent and get response"""
        try:
            # Create a new thread for this conversation
            thread = self.project.agents.threads.create()
            print(self.config.get_message("operations", "thread_created", thread_id=thread.id))

            # Create message
            message = self.project.agents.messages.create(
                thread_id=thread.id,
                role="user",
                content=user_message
            )

            # Run the agent
            run = self.project.agents.runs.create_and_process(
                thread_id=thread.id,
                agent_id=self.agent.id
            )

            if run.status == "failed":
                print(self.config.get_message("errors", "run_failed", error=run.last_error))
                return None
            else:
                # Get messages
                messages = self.project.agents.messages.list(
                    thread_id=thread.id, 
                    order=ListSortOrder.ASCENDING
                )

                # Print conversation
                for message in messages:
                    if message.text_messages:
                        role_label = "User" if message.role == "user" else "Agent"
                        print(f"{role_label} {message.role}: {message.text_messages[-1].text.value}")

                return messages

        except Exception as e:
            print(self.config.get_message("errors", "exception", error=str(e)))
            return None

def main():
    """Main function to run the ticketing agent"""
    config = ConfigManager()
    
    print(config.get_message("user_interface", "welcome"))
    print("=" * 50)
    
    try:
        # Initialize the agent
        agent = TicketingAgent()
        
        print(f"\n{config.get_message('user_interface', 'chat_prompt')}")
        print("Try messages like:")
        for example in config.get_messages_list("user_interface", "examples"):
            print(f"   - '{example}'")
        print("   - Type 'quit' to exit")
        print("-" * 50)
        
        while True:
            user_input = input(f"\n{config.get_message('user_interface', 'input_prompt')}").strip()
            
            if user_input.lower() in ['quit', 'exit', 'q']:
                print(config.get_message("user_interface", "exit_message"))
                break
            
            if user_input:
                agent.chat(user_input)
            
    except Exception as e:
        print(config.get_message("errors", "init_failed", error=str(e)))
        print("\nTroubleshooting:")
        for tip in config.get_messages_list("messages", "troubleshooting"):
            print(f"   - {tip}")

if __name__ == "__main__":
    main()
