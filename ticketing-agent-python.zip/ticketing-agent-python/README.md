# Ticketing Agent - Local Development Setup

This project replicates the Azure AI Foundry Playground ticketing agent functionality in a local VS Code environment.

## Quick Start

### 1. Install Dependencies
```powershell
pip install -r requirements.txt
```

### 2. Configure Environment
Edit `.env` file with your credentials:
- `AZURE_PROJECT_ENDPOINT`: Your Azure AI Project endpoint
- `AZURE_AGENT_ID`: Your agent ID from Azure AI Foundry
- `SERVICENOW_API_TOKEN`: Your ServiceNow API token

### 3. Run the Application
```powershell
python main.py
```

## Project Structure

```
ticketing-agent-python/
├── main.py              # Main application entry point
├── servicenow_api.py    # ServiceNow API integration
├── requirements.txt     # Python dependencies
├── .env                # Environment configuration
└── README.md           # This file
```

## Features

- **IT Assistant**: Classifies and prioritizes issues
- **ServiceNow Integration**: Create, read, and update tickets
- **Azure AI Agent**: Uses your configured agent from Azure AI Foundry
- **Memory**: Remembers last operations for rerun functionality
- **Grammar Correction**: Automatically corrects user input

## Example Usage

```
You: Hi Ticketing Agent
Agent: Hello! I'm your intelligent IT assistant...

You: Create an incident for login issues with high priority
Agent: I'll create a high priority incident for login issues...

You: Update ticket INC0010001 with additional information
Agent: I'll update the ticket with the new information...
```

## Configuration

The agent uses the same prompt and schema from your Azure AI Foundry Playground:
- Classifies issues (Incident vs Problem)
- Prioritizes by impact (1=High, 2=Medium, 3=Low)
- Creates ServiceNow tickets when needed
- Supports rerun functionality
- Tracks user sessions
