import os
import requests
import base64
from typing import Optional, Dict, Any
from dotenv import load_dotenv
from config_manager import ConfigManager

load_dotenv()

class ServiceNowAPI:
    def __init__(self, config_file: str = "config.json"):
        self.config = ConfigManager(config_file)
        self.base_url = os.getenv('SERVICENOW_BASE_URL') or self.config.get_base_url()
        self.username = os.getenv('SERVICENOW_USERNAME')
        self.password = os.getenv('SERVICENOW_PASSWORD')
        self.token = os.getenv('SERVICENOW_API_TOKEN')
        
        # Support both Basic Auth (username/password) and API token
        if self.token and self.token != 'your_servicenow_token_here':
            self.headers = {
                'Authorization': f'Bearer {self.token}',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        elif self.username and self.password:
            # Basic Auth
            credentials = f"{self.username}:{self.password}"
            encoded_credentials = base64.b64encode(credentials.encode()).decode()
            self.headers = {
                'Authorization': f'Basic {encoded_credentials}',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        else:
            print(self.config.get_message("errors", "no_credentials"))
            self.headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        
        self.last_api_call = None
        self.last_action_type = None
        self.user_id = os.getenv('USER_ID', 'current_user')
        
        print(self.config.get_message("initialization", "servicenow_init", endpoint=self.base_url))

    def create_ticket(self, ticket_type: str, short_description: str, urgency: str = None, impact: str = None) -> Dict[str, Any]:
        """Create a new ticket in ServiceNow"""
        operation_config = self.config.get_api_operation("create_ticket")
        
        # Use defaults from config if not provided
        urgency = urgency or self.config.get_default_value("urgency")
        impact = impact or self.config.get_default_value("impact")
        
        # Build URL using endpoint from config
        endpoint = self.config.get_endpoint(f"{ticket_type}s") or f"/table/{ticket_type}"
        url = f"{self.base_url}{endpoint}"
        
        payload = {
            "short_description": short_description,
            "urgency": urgency,
            "impact": impact
        }
        
        print(self.config.get_message("operations", "creating_ticket", 
                                    ticket_type=ticket_type, description=short_description))
        print(f"URL: {url}")
        
        # Store for potential rerun
        self.last_api_call = {"method": operation_config.get("method", "POST"), "url": url, "payload": payload}
        self.last_action_type = "create"
        
        return self._execute_request(self.last_api_call["method"], url, payload)

    def get_ticket(self, query: str, limit: int = None) -> Dict[str, Any]:
        """Get ticket(s) by query"""
        limit = limit or int(self.config.get_default_value("limit"))
        endpoint = self.config.get_endpoint("incidents")
        url = f"{self.base_url}{endpoint}"
        params = {"sysparm_query": query, "sysparm_limit": limit}
        
        print(self.config.get_message("operations", "getting_tickets", query=query))
        
        return self._execute_request("GET", url, params=params)

    def get_user_by_name(self, name: str) -> Dict[str, Any]:
        """Get user sys_id by name"""
        endpoint = self.config.get_endpoint("users")
        url = f"{self.base_url}{endpoint}"
        params = {"sysparm_query": f"name={name}", "sysparm_limit": 1}
        
        return self._execute_request("GET", url, params=params)

    def update_ticket(self, sys_id: str, short_description: str = None, description: str = None) -> Dict[str, Any]:
        """Update a ticket by sys_id"""
        # First, get current ticket data
        current_ticket = self.get_ticket(f"sys_id={sys_id}")
        
        endpoint = self.config.get_endpoint("incidents")
        url = f"{self.base_url}{endpoint}/{sys_id}"
        payload = {}
        
        if short_description:
            payload["short_description"] = short_description
        
        if description:
            # Append to existing description
            current_desc = ""
            if current_ticket.get("result") and len(current_ticket["result"]) > 0:
                current_desc = current_ticket["result"][0].get("description", "")
            payload["description"] = f"{current_desc}\n{description}" if current_desc else description
        
        # Store for potential rerun
        operation_config = self.config.get_api_operation("update_ticket")
        self.last_api_call = {"method": operation_config.get("method", "PATCH"), "url": url, "payload": payload}
        self.last_action_type = "update"
        
        return self._execute_request(self.last_api_call["method"], url, payload)

    def _execute_request(self, method: str, url: str, payload: Dict = None, params: Dict = None) -> Dict[str, Any]:
        """Execute HTTP request with proper error handling"""
        try:
            if method.upper() == "GET":
                response = requests.get(url, params=params, headers=self.headers)
                success_code = 200
            elif method.upper() == "POST":
                response = requests.post(url, json=payload, headers=self.headers)
                success_code = 201
            elif method.upper() == "PATCH":
                response = requests.patch(url, json=payload, headers=self.headers)
                success_code = 200
            else:
                return {"error": f"Unsupported HTTP method: {method}"}
            
            print(f"Response Status: {response.status_code}")
            
            if response.status_code == success_code:
                result = response.json()
                if method.upper() == "POST" and result.get('result', {}).get('number'):
                    ticket_number = result.get('result', {}).get('number', 'Unknown')
                    print(self.config.get_message("operations", "ticket_created", ticket_number=ticket_number))
                return result
            else:
                error_msg = f"Status {response.status_code}: {response.text}"
                print(self.config.get_message("errors", "create_failed", error=error_msg))
                return {"error": error_msg, "status_code": response.status_code}
                
        except Exception as e:
            error_msg = str(e)
            print(self.config.get_message("errors", "exception", error=error_msg))
            return {"error": error_msg}

    def rerun_last_operation(self) -> Dict[str, Any]:
        """Repeat the last API operation"""
        if not self.last_api_call:
            return {"error": "No previous operation to rerun"}
        
        method = self.last_api_call["method"]
        url = self.last_api_call["url"]
        payload = self.last_api_call.get("payload")
        
        return self._execute_request(method, url, payload)
