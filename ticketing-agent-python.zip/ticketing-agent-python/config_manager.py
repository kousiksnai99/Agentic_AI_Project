import json
import os
from typing import Dict, Any, List

class ConfigManager:
    """Configuration manager to handle all JSON-based configurations"""
    
    def __init__(self, config_file: str = "config.json"):
        self.config_file = config_file
        self.config = self.load_config()
    
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Configuration file {self.config_file} not found")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in configuration file: {e}")
    
    def get_azure_config(self) -> Dict[str, str]:
        """Get Azure configuration"""
        return self.config.get("azure", {})
    
    def get_servicenow_config(self) -> Dict[str, Any]:
        """Get ServiceNow configuration"""
        return self.config.get("servicenow", {})
    
    def get_message(self, category: str, key: str, **kwargs) -> str:
        """Get formatted message from configuration"""
        try:
            message_template = self.config["messages"][category][key]
            return message_template.format(**kwargs)
        except KeyError:
            return f"Message not found: {category}.{key}"
    
    def get_messages_list(self, category: str, key: str) -> List[str]:
        """Get list of messages"""
        try:
            return self.config["messages"][category][key]
        except KeyError:
            return []
    
    def get_api_operation(self, operation: str) -> Dict[str, Any]:
        """Get API operation configuration"""
        return self.config.get("api_operations", {}).get(operation, {})
    
    def get_endpoint(self, endpoint_name: str) -> str:
        """Get ServiceNow endpoint path"""
        return self.config["servicenow"]["endpoints"].get(endpoint_name, "")
    
    def get_default_value(self, key: str) -> str:
        """Get default value from configuration"""
        return self.config["servicenow"]["default_values"].get(key, "")
    
    def get_base_url(self) -> str:
        """Get ServiceNow base URL"""
        return self.config["servicenow"]["base_url"]
