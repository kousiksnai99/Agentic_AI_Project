import json
import os
from datetime import datetime

OUTPUT_DIR = "outputs"

def save_json_output(api_name: str, data: dict):
    """
    Save API response data into a timestamped JSON file inside /outputs folder.
    Each API has its own file.
    """
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{api_name}_{timestamp}.json"
    filepath = os.path.join(OUTPUT_DIR, filename)

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    return filepath