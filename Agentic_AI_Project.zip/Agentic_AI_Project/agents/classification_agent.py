class ClassificationAgent:
    """
    Calls the classification Azure AI agent.
    """

    def __init__(self, project_client, agent_id):
        self.project_client = project_client
        self.agent_id = agent_id

    def classify(self, thread_id, issue_description):
        """Send classification request to Azure agent."""
        self.project_client.agents.messages.create(
            thread_id=thread_id,
            role="user",
            content=f"Classify this Outlook issue: {issue_description}"
        )
        self.project_client.agents.runs.create_and_process(
            thread_id=thread_id,
            agent_id=self.agent_id
        )
        messages = list(self.project_client.agents.messages.list(thread_id=thread_id, order="desc"))
        return messages[0].content if messages else None