from agents.classification_agent import ClassificationAgent
from agents.diagnostic_agent import DiagnosticAgent
from agents.troubleshooting_agent import TroubleshootingAgent
from agents.ticketing_agent import TicketingAgent

class OrchestratorAgent:
    """
    Orchestrator Agent: manages the workflow
    classification -> diagnostic -> troubleshooting -> ticketing.
    """

    def __init__(self, project_client, classification_agent_id, diagnostic_agent_id,
                 troubleshooting_agent_id, ticketing_agent_id):
        self.classifier = ClassificationAgent(project_client, classification_agent_id)
        self.diagnostic = DiagnosticAgent(project_client, diagnostic_agent_id)
        self.troubleshooter = TroubleshootingAgent(project_client, troubleshooting_agent_id)
        self.ticketing = TicketingAgent(project_client, ticketing_agent_id)
        self.results = {}

    def run_workflow(self, thread_id, issue_description):
        # 1) Classification
        classi_output = self.classifier.classify(thread_id, issue_description)
        self.results["classification"] = classi_output

        diagnostic_output = None
        troubleshoot_output = None
        ticket_details = None

        if classi_output and "out of scope" not in str(classi_output).lower():
            # Extract classification text
            classification_text = None
            try:
                classification_text = classi_output[0]['text']['value']
            except Exception:
                classification_text = str(classi_output)

            # 2) Diagnostic
            diagnostic_output = self.diagnostic.diagnose(thread_id, classification_text)
            self.results["diagnostic"] = diagnostic_output

            # Extract diagnostic text
            diag_text = None
            try:
                diag_text = diagnostic_output[0]['text']['value']
            except Exception:
                diag_text = str(diagnostic_output)

            # 3) Troubleshooting
            troubleshoot_output = self.troubleshooter.troubleshoot(thread_id, diag_text)
            self.results["troubleshooting"] = troubleshoot_output

            # 4) Ticketing
            if troubleshoot_output:
                ticket_details = self.ticketing.create_ticket(
                    thread_id,
                    f"Issue resolved after troubleshooting. Original: {issue_description}"
                )
            else:
                ticket_details = self.ticketing.create_ticket(
                    thread_id,
                    f"Troubleshooting failed for: {issue_description}"
                )
        else:
            # Out of scope
            ticket_details = self.ticketing.create_ticket(
                thread_id,
                f"Out of scope issue: {issue_description}"
            )

        self.results["ticketing"] = ticket_details
        return self.results