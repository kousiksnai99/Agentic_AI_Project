class TroubleshootingAgent:
    """
    Calls the troubleshooting Azure AI agent to provide remediation steps or scripts.
    """

    def __init__(self, project_client, agent_id):
        self.project_client = project_client
        self.agent_id = agent_id

    def troubleshoot(self, thread_id, diagnostic_result):
        """Send troubleshooting request to Azure agent."""
        self.project_client.agents.messages.create(
            thread_id=thread_id,
            role="user",
            content=f"Provide PowerShell script based on this diagnostic: {diagnostic_result}"
        )
        self.project_client.agents.runs.create_and_process(
            thread_id=thread_id,
            agent_id=self.agent_id
        )
        messages = list(self.project_client.agents.messages.list(thread_id=thread_id, order="desc"))
        return messages[0].content if messages else None