class TicketingAgent:
    """
    Calls the ticketing Azure AI agent to create or update tickets.
    """

    def __init__(self, project_client, agent_id):
        self.project_client = project_client
        self.agent_id = agent_id

    def create_ticket(self, thread_id, issue_summary):
        """Send ticketing request to Azure agent."""
        self.project_client.agents.messages.create(
            thread_id=thread_id,
            role="user",
            content=issue_summary
        )
        self.project_client.agents.runs.create_and_process(
            thread_id=thread_id,
            agent_id=self.agent_id
        )
        messages = list(self.project_client.agents.messages.list(thread_id=thread_id, order="desc"))
        return messages[0].content if messages else None