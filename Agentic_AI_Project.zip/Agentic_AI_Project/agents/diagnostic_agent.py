class DiagnosticAgent:
    """
    Calls the diagnostic Azure AI agent to identify root cause of the issue.
    """

    def __init__(self, project_client, agent_id):
        self.project_client = project_client
        self.agent_id = agent_id

    def diagnose(self, thread_id, classification_result):
        """Send diagnostic request to Azure agent."""
        self.project_client.agents.messages.create(
            thread_id=thread_id,
            role="user",
            content=f"Diagnose the root cause for: {classification_result}"
        )
        self.project_client.agents.runs.create_and_process(
            thread_id=thread_id,
            agent_id=self.agent_id
        )
        messages = list(self.project_client.agents.messages.list(thread_id=thread_id, order="desc"))
        return messages[0].content if messages else None