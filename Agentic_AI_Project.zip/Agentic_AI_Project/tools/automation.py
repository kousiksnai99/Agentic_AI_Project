import time
import uuid
from azure.identity import ClientSecretCredential
from azure.mgmt.automation import AutomationClient
from azure.mgmt.automation.models import (
    RunbookCreateOrUpdateParameters,
    JobCreateParameters
)
from app.config import (
    TENANT_ID,
    CLIENT_ID,
    CLIENT_SECRET,
    SUBSCRIPTION_ID,
    AZURE_RESOURCE_GROUP,
    AUTOMATION_ACCOUNT,
    HYBRID_WORKER_GROUP,
    AUTOMATION_LOCATION
)

# -------------------------
# Authentication + Client
# -------------------------
credential = ClientSecretCredential(
    tenant_id=TENANT_ID,
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET
)
automation_client = AutomationClient(credential, SUBSCRIPTION_ID)

# -------------------------
# Upload + Publish Runbook (UNCHANGED)
# -------------------------
def upload_and_publish_runbook(script_text: str, runbook_name: str):
    """
    Creates a new runbook, uploads script, and publishes it.
    """
    try:
        print(f"[INFO] Creating/Updating runbook: {runbook_name}")

        runbook_params = RunbookCreateOrUpdateParameters(
            name=runbook_name,
            location=AUTOMATION_LOCATION,
            log_verbose=True,
            log_progress=True,
            runbook_type="PowerShellWorkflow",  # ✅ same as your working code
            description=f"Dynamic Runbook {runbook_name} created via API"
        )

        automation_client.runbook.create_or_update(
            resource_group_name=AZURE_RESOURCE_GROUP,
            automation_account_name=AUTOMATION_ACCOUNT,
            runbook_name=runbook_name,
            parameters=runbook_params
        )

        # Upload draft script
        poller = automation_client.runbook_draft.begin_replace_content(
            resource_group_name=AZURE_RESOURCE_GROUP,
            automation_account_name=AUTOMATION_ACCOUNT,
            runbook_name=runbook_name,
            runbook_content=script_text
        )
        poller.result()

        # Publish runbook
        publish_poller = automation_client.runbook.begin_publish(
            resource_group_name=AZURE_RESOURCE_GROUP,
            automation_account_name=AUTOMATION_ACCOUNT,
            runbook_name=runbook_name
        )
        publish_poller.result()

        print(f"[SUCCESS] Runbook {runbook_name} uploaded & published")
        return {"runbook_name": runbook_name, "status": "uploaded"}

    except Exception as e:
        print(f"[ERROR] Runbook upload failed: {e}")
        return {"runbook_name": runbook_name, "status": "failed", "error": str(e)}

# -------------------------
# Execute Runbook Job (ONLY Step E changed)
# -------------------------
def execute_runbook(script_text: str):
    """
    Dynamically creates a new runbook, publishes it, executes it on Hybrid Worker,
    and fetches only relevant PowerShell output.
    """
    try:
        runbook_name = f"runbook_{uuid.uuid4().hex[:6]}"
        print(f"[INFO] Generated runbook name: {runbook_name}")

        # Upload + Publish
        upload_status = upload_and_publish_runbook(script_text, runbook_name)
        if upload_status.get("status") != "uploaded":
            print(f"[ERROR] Upload failed: {upload_status}")
            return {"status": "failed", "error": upload_status.get("error")}

        # Create job
        job_name = f"{runbook_name}_job_{uuid.uuid4().hex[:8]}"
        print(f"[INFO] Creating job: {job_name}")

        job_params = JobCreateParameters(
            runbook={"name": runbook_name},
            run_on=HYBRID_WORKER_GROUP
        )
        job = automation_client.job.create(
            resource_group_name=AZURE_RESOURCE_GROUP,
            automation_account_name=AUTOMATION_ACCOUNT,
            job_name=job_name,
            parameters=job_params
        )
        job_id = job.job_id
        print(f"[SUCCESS] Job created with ID: {job_id}")

        # Poll until job completes
        while True:
            job_status = automation_client.job.get(
                resource_group_name=AZURE_RESOURCE_GROUP,
                automation_account_name=AUTOMATION_ACCOUNT,
                job_name=job_name
            )
            state = job_status.status.lower()
            print(f"[DEBUG] Job {job_name} status: {state}")
            if state in ["completed", "failed", "stopped", "suspended"]:
                break
            time.sleep(5)

        # Step E: Collect stdout safely
        stdout = []
        pager = automation_client.job_stream.list_by_job(
            resource_group_name=AZURE_RESOURCE_GROUP,
            automation_account_name=AUTOMATION_ACCOUNT,
            job_name=job_name
        )
        for stream in pager:
            sdict = stream.as_dict()
            stype = (sdict.get("stream_type") or "").lower()
            stext = sdict.get("stream_text") or sdict.get("summary") or ""

            # Debug print in terminal
            print(f"[STREAM] type={stype} text={stext.strip()}")

            # Collect only real script output
            if stype == "output" and stext.strip():
                stdout.append(stext.strip())
            # fallback: sometimes PS output is misclassified as Information
            elif stype in ["information"] and stext.strip():
                stdout.append(stext.strip())

        print(f"[SUCCESS] Job {job_name} finished with status: {job_status.status}")
        return {
            "runbook_name": runbook_name,
            "job_id": job_id,
            "status": job_status.status,
            "stdout": stdout
        }

    except Exception as e:
        print(f"[ERROR] Exception in execute_runbook: {e}")
        return {"status": "failed", "exception": str(e), "stdout": []}