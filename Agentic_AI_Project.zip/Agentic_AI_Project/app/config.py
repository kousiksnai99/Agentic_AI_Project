import os
from dotenv import load_dotenv
from azure.identity import ClientSecretCredential
from azure.ai.projects import AIProjectClient
from openai import AzureOpenAI

load_dotenv()
AUTOMATION_LOCATION = "East US2" 
# --------------------
# Required ENV variables
# --------------------
CLIENT_ID = os.getenv('AZURE_CLIENT_ID')
CLIENT_SECRET = os.getenv('AZURE_CLIENT_SECRET')
TENANT_ID = os.getenv('AZURE_TENANT_ID')
SUBSCRIPTION_ID = os.getenv('AZURE_SUBSCRIPTION_ID')
RESOURCE_GROUP = os.getenv('AZURE_RESOURCE_GROUP')
PROJECT_NAME = os.getenv('AZURE_PROJECT_NAME')
PROJECT_ENDPOINT = os.getenv('PROJECT_ENDPOINT')

# --------------------
# Agent IDs
# --------------------
CLASSIFICATION_AGENT_ID = os.getenv('CLASSIFICATION_AGENT_ID')
DIAGNOSTIC_AGENT_ID = os.getenv('DIAGNOSTIC_AGENT_ID')
TROUBLESHOOTING_AGENT_ID = os.getenv('TROUBLESHOOTING_AGENT_ID')
TICKETING_AGENT_ID = os.getenv('TICKETING_AGENT_ID')

# --------------------
# OpenAI Deployment
# --------------------
AZURE_ENDPOINT = os.getenv('AZURE_ENDPOINT')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
DEPLOYMENT_NAME = os.getenv('DEPLOYMENT_NAME', 'gpt-4o-mini')

# --------------------
# Azure Automation (NEW)
# --------------------
AZURE_RESOURCE_GROUP = os.getenv('AZURE_RESOURCE_GROUP')
AUTOMATION_ACCOUNT = os.getenv('AUTOMATION_ACCOUNT')
RUNBOOK_NAME = os.getenv('RUNBOOK_NAME')
HYBRID_WORKER_GROUP = os.getenv('HYBRID_WORKER_GROUP')

# --------------------
# Azure Credentials
# --------------------
credential = ClientSecretCredential(
    tenant_id=TENANT_ID,
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET
)

# --------------------
# Clients
# --------------------
openai_client = AzureOpenAI(
    api_version="2024-12-01-preview",
    azure_endpoint=AZURE_ENDPOINT,
    api_key=OPENAI_API_KEY
)

project_client = AIProjectClient(
    endpoint=PROJECT_ENDPOINT,
    credential=credential
)

# --------------------
# Debug log
# --------------------
def log_config():
    print("Configuration and clients initialized successfully.")
    print(f"Resource Group: {AZURE_RESOURCE_GROUP}")
    print(f"Automation Account: {AUTOMATION_ACCOUNT}")
    print(f"Runbook Name: {RUNBOOK_NAME}")
    print(f"Hybrid Worker Group: {HYBRID_WORKER_GROUP}")
log_config()