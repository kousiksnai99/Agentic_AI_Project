from pydantic import BaseModel
from typing import Optional

class OutlookIssue(BaseModel):
    issue_description: str

class WorkflowResponse(BaseModel):
    thread_id: str
    trace_id: str
    status: str
    classification_result: Optional[str] = None
    diagnostic_result: Optional[str] = None
    troubleshooting_result: Optional[str] = None
    ticket_details: Optional[str] = None