from fastapi import FastAPI, HTTPException
import uuid

from app.schemas import OutlookIssue, WorkflowResponse
from app.config import (
    project_client,
    CLASSIFICATION_AGENT_ID,
    DIAGNOSTIC_AGENT_ID,
    TROUBLESHOOTING_AGENT_ID,
    TICKETING_AGENT_ID
)
from agents.orchestrator_agent import OrchestratorAgent
from agents.diagnostic_agent import DiagnosticAgent
from utils.file_utils import save_json_output
from tools.automation import execute_runbook
from tools.automation import upload_and_publish_runbook




app = FastAPI(title="Outlook Issue Resolution API")

@app.get("/")
def root():
    return {
        "message": "✅ Outlook Issue Resolution API is running",
        "docs": "Visit /docs for interactive API documentation",
        "health": "OK"
    }

# -------------------
# FULL WORKFLOW API
# -------------------
@app.post("/api/outlook/resolve", response_model=WorkflowResponse)
async def resolve_outlook_issue(issue: OutlookIssue):
    try:
        orchestrator = OrchestratorAgent(
            project_client,
            classification_agent_id=CLASSIFICATION_AGENT_ID,
            diagnostic_agent_id=DIAGNOSTIC_AGENT_ID,
            troubleshooting_agent_id=TROUBLESHOOTING_AGENT_ID,
            ticketing_agent_id=TICKETING_AGENT_ID
        )

        thread = project_client.agents.threads.create()
        thread_id = thread.id
        trace_id = str(uuid.uuid4())

        results = orchestrator.run_workflow(thread_id, issue.issue_description)

        def extract_text(agent_output):
            if agent_output and isinstance(agent_output, list):
                try:
                    return agent_output[0]['text']['value']
                except Exception:
                    return str(agent_output)
            return str(agent_output) if agent_output else ""

        response = WorkflowResponse(
            thread_id=thread_id,
            trace_id=trace_id,
            status="completed",
            classification_result=extract_text(results.get("classification")),
            diagnostic_result=extract_text(results.get("diagnostic")),
            troubleshooting_result=extract_text(results.get("troubleshooting")),
            ticket_details=extract_text(results.get("ticketing"))
        )

        save_json_output("resolve_workflow", response.dict())
        return response

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# -------------------
# DIAGNOSTIC-ONLY API
# -------------------
@app.post("/api/outlook/diagnostic/run")
async def diagnostic_with_execution(issue: OutlookIssue):
    try:
        diagnostic_agent = DiagnosticAgent(project_client, DIAGNOSTIC_AGENT_ID)

        thread = project_client.agents.threads.create()
        thread_id = thread.id
        trace_id = str(uuid.uuid4())

        diagnostic_output = diagnostic_agent.diagnose(thread_id, issue.issue_description)

        def extract_text(agent_output):
            if agent_output and isinstance(agent_output, list):
                try:
                    return agent_output[0]['text']['value']
                except Exception:
                    return str(agent_output)
            return str(agent_output) if agent_output else ""

        diagnostic_text = extract_text(diagnostic_output)

        # 🔥 Now fetch output JSON from Azure Automation
        automation_result = execute_runbook(diagnostic_text)

        response = {
            "thread_id": thread_id,
            "trace_id": trace_id,
            "status": "completed",
            "diagnostic_result": diagnostic_text,
            "automation_result": automation_result  # stdout/stderr from script
        }

        save_json_output("diagnostic_api_run", response)
        return response

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
 


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)