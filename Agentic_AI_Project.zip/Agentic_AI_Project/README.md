# Outlook Issue Resolution API (Agent-based, modular)

## Overview
This project uses Azure AI Projects agents in an AutoGen-style workflow:
- **agents/**: independent AI agent modules (orchestrator + specialized agents)
- **app/**: FastAPI app-level code (schemas, config)
- **main.py**: single FastAPI entry point

## Setup

1. Create a virtualenv and install dependencies:
```bash
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt