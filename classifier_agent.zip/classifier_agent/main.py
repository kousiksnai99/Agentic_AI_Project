#!/usr/bin/env python3
"""
Azure AI Classifier Agent - Interactive Chat Interface

This module provides a command-line interface for interacting with an Azure AI
classifier agent. It handles authentication, thread management, message processing,
and provides a clean chat experience.

Features:
- Interactive chat interface with Azure AI agent
- Automatic thread creation and management
- Robust error handling and logging
- Environment-based configuration
- Graceful exit handling

Requirements:
- Azure AI Project with configured agent
- Valid Azure credentials
- Environment configuration in .env file

Usage:
    python main.py

Author: Azure AI Team
Date: August 2025
"""

import os
import sys
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential
from azure.ai.agents.models import ListSortOrder
from azure.core.exceptions import AzureError
import logging

# Configure logging to reduce verbosity from Azure SDK
# This prevents excessive debug output while maintaining error visibility
logging.getLogger("azure").setLevel(logging.ERROR)
logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(logging.ERROR)
logging.getLogger("msal").setLevel(logging.ERROR)


class ClassifierAgent:
    """
    Azure AI Classifier Agent with clean interface.
    
    This class provides a simple interface to interact with Azure AI Project
    classifier agents. It handles authentication, thread management, and
    message processing automatically.
    
    Attributes:
        endpoint (str): Azure AI Project endpoint URL
        agent_id (str): Azure AI agent identifier
        credential: Azure authentication credential
        project: Azure AI Project client instance
    """
    
    def __init__(self):
        """
        Initialize the classifier agent with Azure credentials and configuration.
        
        Loads environment variables from .env file and sets up Azure AI Project client.
        
        Raises:
            ValueError: If required Azure configuration is missing
            Exception: If Azure client initialization fails
        """
        # Load environment variables from .env file
        load_dotenv()
        
        # Get Azure configuration from environment variables
        self.endpoint = os.getenv('AZURE_AI_PROJECT_ENDPOINT')
        self.agent_id = os.getenv('AZURE_AGENT_ID')
        
        # Validate required configuration
        if not self.endpoint or not self.agent_id:
            raise ValueError("Missing Azure configuration in .env file")
        
        try:
            # Initialize Azure credentials using DefaultAzureCredential
            # This will try multiple authentication methods in order
            self.credential = DefaultAzureCredential()
            
            # Create Azure AI Project client
            self.project = AIProjectClient(
                credential=self.credential,
                endpoint=self.endpoint
            )
        except Exception as e:
            raise Exception(f"Failed to initialize Azure client: {e}")
    
    def chat(self, user_input):
        """
        Send message to agent and get response.
        
        Creates a new thread, sends user message, processes it with the agent,
        and returns the agent's response.
        
        Args:
            user_input (str): The user's message to send to the agent
            
        Returns:
            str: The agent's response or error message
        """
        try:
            # Retrieve the configured agent from Azure AI Project
            agent = self.project.agents.get_agent(self.agent_id)
            
            # Create a new conversation thread
            thread = self.project.agents.threads.create()
            
            # Add user message to the thread
            self.project.agents.messages.create(
                thread_id=thread.id,
                role="user",
                content=user_input
            )
            
            # Execute the agent to process the message and generate response
            run = self.project.agents.runs.create_and_process(
                thread_id=thread.id,
                agent_id=agent.id
            )
            
            # Check if the run failed
            if run.status == "failed":
                return f"Error: {run.last_error}"
            
            # Retrieve all messages from the thread in ascending order
            messages = self.project.agents.messages.list(
                thread_id=thread.id, 
                order=ListSortOrder.ASCENDING
            )
            
            # Find the most recent assistant response
            # Iterate in reverse to get the latest message first
            for message in reversed(list(messages)):
                if message.role == "assistant" and message.text_messages:
                    return message.text_messages[-1].text.value
            
            return "No response from agent"
            
        except Exception as e:
            return f"Error: {e}"

def main():
    """
    Main chat interface for the Azure AI Classifier Agent.
    
    Initializes the classifier agent and provides an interactive chat loop
    where users can send messages and receive responses from the agent.
    """
    print("Initializing Azure AI Classifier Agent...")
    
    try:
        # Initialize the classifier agent with Azure configuration
        classifier = ClassifierAgent()
        print("Connected to classifier agent!")
        print("Start chatting! (Type 'quit' to exit)\n")
        
        # Main chat loop
        while True:
            try:
                # Get user input from command line
                user_input = input("You: ").strip()
                
                # Check for exit commands
                if user_input.lower() in ['quit', 'exit', 'bye', 'q']:
                    print("Goodbye!")
                    break
                
                # Skip empty inputs
                if not user_input:
                    continue
                
                # Send message to agent and get response
                print("Agent is thinking...")
                response = classifier.chat(user_input)
                
                # Display agent response
                print(f"Agent: {response}\n")
                
            except KeyboardInterrupt:
                # Handle Ctrl+C gracefully
                print("\nGoodbye!")
                break
            except Exception as e:
                # Handle any other errors in the chat loop
                print(f"Error: {e}\n")
    
    except Exception as e:
        # Handle initialization errors
        print(f"Failed to start: {e}")
        print("Make sure your .env file has the correct Azure configuration")
        sys.exit(1)

if __name__ == "__main__":
    # Entry point - run the main chat interface when script is executed directly
    main()