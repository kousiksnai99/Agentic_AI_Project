# Azure AI Classifier Agent

A Python implementation of an Azure AI classifier agent that demonstrates how to interact with Azure AI Project Client to create threads, send messages, and process responses.

## Project Structure

```
classifier_agent/
├── .env                    # Environment variables (Azure configuration)
├── requirements.txt        # Python dependencies
├── main.py                # Main classifier agent implementation
├── .venv/                 # Virtual environment (auto-generated)
└── README.md              # This file
```

## Setup Instructions

### 1. Prerequisites

- Python 3.8 or higher
- Azure AI Project with a configured agent
- Azure authentication (Azure CLI recommended)

### 2. Environment Setup

The virtual environment is already configured. Install dependencies:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

### 3. Configuration

Update the `.env` file with your Azure AI Project details:

```env
AZURE_AI_PROJECT_ENDPOINT=https://your-project.services.ai.azure.com/api/projects/your-project
AZURE_AGENT_ID=your_agent_id
```

### 4. Authentication

Make sure you're authenticated with Azure:

```powershell
az login
```

### 5. Run the Application

```powershell
.\.venv\Scripts\python.exe main.py
```

## Features

- **Interactive Chat Interface**: Chat with your Azure AI classifier agent
- **Error Handling**: Robust error handling and logging
- **Environment Configuration**: Secure credential management with .env
- **Virtual Environment**: Isolated Python environment
- **Logging**: Detailed logging for debugging and monitoring

## Usage

1. Run the script: `python main.py`
2. Enter your messages when prompted
3. The agent will process your input and respond
4. Type 'quit', 'exit', or 'bye' to end the conversation

## Troubleshooting

### Common Issues

1. **Import Errors**: Ensure all dependencies are installed with `pip install -r requirements.txt`
2. **Authentication Errors**: Run `az login` to authenticate with Azure
3. **Agent Not Found**: Verify the `AZURE_AGENT_ID` in your `.env` file
4. **Endpoint Issues**: Check the `AZURE_AI_PROJECT_ENDPOINT` URL

### Debug Mode

For detailed logging, the application automatically logs important events and errors.

## Dependencies

- `azure-ai-projects`: Azure AI Project client library
- `azure-identity`: Azure authentication library
- `python-dotenv`: Environment variable management

## License

This project is for demonstration purposes.
