from azure.identity import ClientSecretCredential
from azure.ai.projects import AIProjectClient
from azure.mgmt.automation import AutomationClient
from azure.mgmt.automation.models import RunbookCreateOrUpdateParameters, RunbookTypeEnum, JobCreateParameters
from openai import AzureOpenAI
import os
import json
import uuid
from dotenv import load_dotenv
from autogen import AssistantAgent, UserProxyAgent

load_dotenv()
client_id = os.getenv('AZURE_CLIENT_ID')
client_secret = os.getenv('AZURE_CLIENT_SECRET')
tenant_id = os.getenv('AZURE_TENANT_ID')
subscription_id = os.getenv('AZURE_SUBSCRIPTION_ID')
resource_group = os.getenv('AZURE_RESOURCE_GROUP')
project_name = os.getenv('AZURE_PROJECT_NAME')
project_endpoint = os.getenv('PROJECT_ENDPOINT')      #AIProjectClient
azure_endpoint = os.getenv('AZURE_ENDPOINT')          #AzureOpenAI
automation_account = os.getenv('AUTOMATION_ACCOUNT')
hybrid_worker_group = os.getenv('HYBRID_WORKER_GROUP')
openai_api_key = os.getenv('OPENAI_API_KEY')
deployment_name = "gpt-4o"
# os.environ["AUTOGEN_USE_DOCKER"] = "0"

# Azure OpenAI client (for LLM calls)
openai_client = AzureOpenAI(
    api_version="2024-12-01-preview",
    azure_endpoint=azure_endpoint,
    api_key=openai_api_key
)

# Azure AI Project client (for agent orchestration)
credential = ClientSecretCredential(
    tenant_id=tenant_id,
    client_id=client_id,
    client_secret=client_secret
)
project_client = AIProjectClient(
    endpoint=project_endpoint,
    credential=credential
)
automation_client = AutomationClient(credential, subscription_id)

classification_agent_id = "asst_80rdCpXQLdOxKihVdvDiJWMJ"
troubleshooting_agent_id = "asst_KLpsUqgcCno3oSdCY9zbrybw"
ticketing_agent_id = "asst_RX1x1WbM3zT7QASREPWrUxy8"
runbook_name = "Runbook_Kalpa"

class AutoGenWorkflowManager:
    def __init__(self, project_client):
        self.project_client = project_client
        self.tasks = {}
        self.results = {}
        self.completed_tasks = set()
        
        self.classification_agent_id = "asst_80rdCpXQLdOxKihVdvDiJWMJ"
        self.troubleshooting_agent_id = "asst_KLpsUqgcCno3oSdCY9zbrybw"
        self.ticketing_agent_id = "asst_RX1x1WbM3zT7QASREPWrUxy8"

    def add_task(self, task_id, description, dependencies=None):
        self.tasks[task_id] = {
            "description": description,
            "status": "pending",
            "dependencies": dependencies or []
        }

    def get_ready_tasks(self):
        return [
            task_id for task_id, task in self.tasks.items()
            if task["status"] == "pending" and all(dep in self.completed_tasks for dep in task["dependencies"])
        ]

    def execute_task(self, task_id, thread_id):
        task = self.tasks[task_id]
        print(f"\n--- Executing: {task_id} ---")
        try:
            if task_id == "classify_issue":
                agent_id = self.classification_agent_id
            elif task_id == "troubleshoot_issue":
                agent_id = self.troubleshooting_agent_id
            elif task_id == "ticketing":
                agent_id = self.ticketing_agent_id

            self.project_client.agents.messages.create(
                thread_id=thread_id,
                role="user",
                content=task["description"]
            )
            run = self.project_client.agents.runs.create_and_process(
                thread_id=thread_id,
                agent_id=agent_id
            )
            messages = list(self.project_client.agents.messages.list(thread_id=thread_id, order="desc"))
            response = messages[0].content if messages else None
            
            self.results[task_id] = response
            self.completed_tasks.add(task_id)
            task["status"] = "completed"
            print(f"[OK] Completed: {task_id}")
            return response
        except Exception as e:
            task["status"] = "failed"
            print(f"[FAIL] Failed: {task_id} | Error: {e}")
            return None

    def run(self, thread_id):
        while len(self.completed_tasks) < len(self.tasks):
            ready = self.get_ready_tasks()
            if not ready:
                print("No tasks ready. Possibly circular dependencies or failed tasks.")
                break
            for task_id in ready:
                self.execute_task(task_id, thread_id)
        return self.results

def save_and_publish_runbook(runbook_name, runbook_content):
    runbook_params = RunbookCreateOrUpdateParameters(
        name=runbook_name,
        location="East US2",
        runbook_type=RunbookTypeEnum.POWER_SHELL,
        log_verbose=True,
        log_progress=True,
        description="Runbook created using Troubleshooting agent output",
    )
    automation_client.runbook.create_or_update(
        resource_group_name=resource_group,
        automation_account_name=automation_account,
        runbook_name=runbook_name,
        parameters=runbook_params,
    )
    automation_client.runbook_draft.begin_replace_content(
        resource_group_name=resource_group,
        automation_account_name=automation_account,
        runbook_name=runbook_name,
        runbook_content=runbook_content
    )
    publish_poller = automation_client.runbook.begin_publish(
        resource_group_name=resource_group,
        automation_account_name=automation_account,
        runbook_name=runbook_name
    )
    publish_poller.result()
    runbook = automation_client.runbook.get(
        resource_group_name=resource_group,
        automation_account_name=automation_account,
        runbook_name=runbook_name
    )
    if hasattr(runbook, "state") and runbook.state == "Published":
        print(f"Runbook '{runbook_name}' is published.")
    else:
        print(f"Runbook '{runbook_name}' is NOT published. Current state: {getattr(runbook, 'state', 'Unknown')}")
    return runbook

def start_runbook_on_hybrid_worker(runbook_name, hybrid_worker_group, parameters=None):
    parameters = parameters or {}
    job_name = f"{runbook_name}_job_{uuid.uuid4().hex[:8]}"
    job_parameters = JobCreateParameters(
        runbook={"name": runbook_name},
        parameters=parameters,
        run_on=hybrid_worker_group
    )
    runbook_job = automation_client.job.create(
        resource_group_name=resource_group,
        automation_account_name=automation_account,
        job_name=job_name,
        parameters=job_parameters
    )
    print(f"Runbook '{runbook_name}' started on hybrid worker group '{hybrid_worker_group}'. Job ID: {runbook_job.job_id}")
    job = automation_client.job.get(
        resource_group_name=resource_group,
        automation_account_name=automation_account,
        job_name=job_name
    )
    print(f"Job status: {job.status}")
    print(f"Job exception: {job.exception}")
    return job

def orchestrate_workflow():
    workflow = AutoGenWorkflowManager(project_client)
    user_input = input("Describe your Outlook issue: ").strip()
    thread = project_client.agents.threads.create()
    thread_id = thread.id
    trace_id = str(uuid.uuid4())
    
    with open("conversation_trace.json", "w") as f:
        json.dump({"trace_id": trace_id, "thread_id": thread_id}, f)
    
    workflow.add_task("classify_issue", f"Classify this Outlook issue: {user_input}")
    workflow.execute_task("classify_issue", thread_id)
    classi_output = workflow.results.get("classify_issue")
    
    if classi_output and "out of scope" not in str(classi_output).lower():
        classi_output_text = classi_output[0]['text']['value']
        workflow.add_task("troubleshoot_issue", f"Based on the following issue summary, please provide a PowerShell script: {classi_output_text}")
        workflow.execute_task("troubleshoot_issue", thread_id)
        
        troubleshoot_output = workflow.results.get("troubleshoot_issue")
        if troubleshoot_output and isinstance(troubleshoot_output, list) and troubleshoot_output[0].get('type') == 'text':
            final_output_text = troubleshoot_output[0]['text']['value']
            print("Troubleshooting Agent Output:")
            print(final_output_text)
            
            runbook = save_and_publish_runbook(runbook_name, final_output_text)
            print(f"Script saved and published to runbook '{runbook_name}'.")
            job = start_runbook_on_hybrid_worker(runbook_name, hybrid_worker_group)
            
            if job.status == "Failed":
                print("Troubleshooting failed. Escalating to ticketing agent.")
                failure_context = f"Troubleshooting attempt failed. Original issue: {user_input}. Job failed with: {job.exception}"
                workflow.add_task("ticketing", failure_context)
                workflow.execute_task("ticketing", thread_id)
            else:
                print(f"Job status: {job.status}")
                user_satisfied = input("Did this solve your issue? (Y/N): ").strip().upper()
                if user_satisfied != 'Y':
                    failure_context = f"User reported issue not resolved. Original issue: {user_input}."
                    workflow.add_task("ticketing", failure_context)
                    workflow.execute_task("ticketing", thread_id)
        else:
            print("Troubleshooting agent did not return a script. Escalating to ticketing agent.")
            failure_context = f"Troubleshooting agent failed to provide solution for: {user_input}"
            workflow.add_task("ticketing", failure_context)
            workflow.execute_task("ticketing", thread_id)
    else:
        print("Issue is out of scope. Passing to ticketing agent")
        workflow.add_task("ticketing", "This issue is out of scope. Please raise a ticket for this issue.")
        workflow.execute_task("ticketing", thread_id)
    
    return thread_id, trace_id, workflow.results



if __name__ == "__main__":
    orchestrate_workflow()