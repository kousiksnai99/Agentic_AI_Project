#####################################################################################
## Project name : ServiceNow Agent (real ServiceNow ticketing API)                  #
## Business owner , Team : Data and AIA                                             #
## Purpose of Function:                                                             #
##   HTTP-triggered Azure Function that fronts the Teva ServiceNow ticketing API.   #
##   It reads a flat JSON payload (each action sends only the fields it needs) and  #
##   returns the incident id in the exact fields the orchestrator reads. The legacy #
##   "action=... | key=value" message string still works.                           #
##                                                                                  #
##   Every request is turned into a REAL call against                                #
##     {BASE_URL}/api/tpi/tevagenericwebservice/incident/{RESOURCE_PATH}            #
##   so the ticket numbers come from ServiceNow and are never invented.             #
##                                                                                  #
##   Authentication:                                                                #
##     Microsoft Entra ID client_credentials -> Bearer token (valid ~1h, cached     #
##     per worker and refreshed 5 min before expiry). The gateway also accepts an   #
##     x-Gateway-APIKey header; set SN_API_KEY to send it alongside the token.      #
##                                                                                  #
##   Single-incident-per-conversation:                                              #
##     On create we stamp u_inbound_key = conversation_id. update/resolve without   #
##     an explicit incident_id look the incident up by that key, so the SAME        #
##     incident is managed across every action in a conversation with no server-    #
##     side cache.                                                                  #
##                                                                                  #
##   Actions handled (request fields -> response fields):                           #
##     {"conversation_id", "action": "create_incident", "issue_type", "details"}     #
##         -> {"incident_id", "issue_type", "state", "message"}                     #
##     {"conversation_id", "action": "update_incident", "incident_id", "note"}       #
##         -> {"incident_id", "note", "message"}                                    #
##     {"conversation_id", "action": "resolve", "incident_id", "note"}               #
##         -> {"incident_id", "state", "message"}                                   #
##     {"conversation_id", "action": "get_incident", "incident_id"}                  #
##         -> {"incident_id", "state", "short_description", "message"}              #
##                                                                                  #
##   NOTE: the gateway exposes no 'interaction' table, so create_interaction /      #
##   close_interaction are no longer supported and return HTTP 400.                 #
#####################################################################################

# # Load all the libraries
import json
import logging
import os
import threading
import time

import azure.functions as func
import requests


#=============================Logging Setup========================================================
logging.getLogger().setLevel(logging.INFO)


#=============================Configuration========================================================
# Entra ID (client credentials). SN_CLIENT_SECRET should be supplied via App Settings /
# Key Vault in any real environment -- the literal below is the client-provided dev secret.
TENANT_ID = os.getenv("SN_TENANT_ID", "3f991a7b-ea93-4169-b28c-c36ff3e5b0d1")
CLIENT_ID = os.getenv("SN_CLIENT_ID", "e91e93ca-955f-47d5-a491-a41985414c57")
CLIENT_SECRET = os.getenv("SN_CLIENT_SECRET", "1c98Q~KxkROmy8Uyw8gSixhI6Dv7tdhnAzIO1a2n")
SCOPE = os.getenv("SN_SCOPE", "api://7f70f393-ab7d-4e6b-a92e-952c23dbcba9/.default")

# Gateway. RESOURCE_PATH is the client-issued token that scopes this caller to the
# incident table -- the same value works for GET / POST / PUT.
BASE_URL = os.getenv("SN_BASE_URL", "https://apidev.tevapharm.com/gateway/serviceNowTicketingAPI/1.0")
RESOURCE_PATH = os.getenv("SN_RESOURCE_PATH", "a96d6adb3ba2cf1079901b9aa4e45a2f")
# x-Gateway-APIKey from the client's Postman collection. The Bearer token alone is
# sufficient (verified), so this is belt-and-braces; set SN_API_KEY="" to stop sending it.
API_KEY = os.getenv("SN_API_KEY", "531b46e7-b089-4225-a998-325accf964e1").strip()

# Field defaults required by the ServiceNow data policy on incident.
#   u_ticket_source / u_customer_ci are MANDATORY on create; description too.
#   SN_CUSTOMER_CI below is a placeholder CI discovered in the dev instance -- the
#   business must confirm the correct Customer CI for this agent.
TICKET_SOURCE = os.getenv("SN_TICKET_SOURCE", "Self-service")
CUSTOMER_CI = os.getenv("SN_CUSTOMER_CI", "5df3b00a4f775a004e1e3c728110c702")
RESOLUTION_METHOD = os.getenv("SN_RESOLUTION_METHOD", "Automated")
CLOSE_CODE = os.getenv("SN_CLOSE_CODE", "Solved (Permanently)")
RESOLVED_STATE = os.getenv("SN_RESOLVED_STATE", "6")

HTTP_TIMEOUT = 30
TOKEN_URL = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
INCIDENT_URL = f"{BASE_URL}/api/tpi/tevagenericwebservice/incident/{RESOURCE_PATH}"

SUPPORTED_ACTIONS = ("create_incident", "update_incident", "resolve", "get_incident")


class ServiceNowError(Exception):
    """ServiceNow answered 200 but with {"result": {"hasError": true, "errorMsg": ...}}."""


#==============================================Utilities===========================================
def json_response(payload: dict, status: int = 200) -> func.HttpResponse:
    """Return a JSON HTTP response (ensure_ascii=False keeps any non-Latin text readable)."""
    return func.HttpResponse(
        body=json.dumps(payload, ensure_ascii=False),
        status_code=status,
        mimetype="application/json",
    )


def extract_request(req: func.HttpRequest) -> tuple:
    """Read the flat JSON payload: {"conversation_id", "action", <fields for that action>}.

    Every action sends ONLY the fields it needs, e.g.
        {"conversation_id": "conv-1001", "action": "create_incident",
         "issue_type": "email", "details": "Outlook will not start"}
    Query params (?conversation_id=...&action=...) work the same way for quick manual
    testing, and the legacy {"message": "action=... | key=value"} string is still
    accepted. Returns (conversation_id, fields).
    """
    try:
        body = req.get_json()
    except (ValueError, AttributeError):
        # Not JSON, or no body at all (a GET carrying only query params).
        body = None
    if not isinstance(body, dict):
        body = {}

    conversation_id = str(body.get("conversation_id") or req.params.get("conversation_id") or "")

    # Flat JSON body wins; query params fill any gap. Values are stringified so a numeric
    # or boolean JSON value still renders cleanly.
    fields = {k: str(v) for k, v in body.items() if k != "conversation_id" and v is not None}
    for key, value in req.params.items():
        if key != "conversation_id":
            fields.setdefault(key, value)

    # Legacy path: no flat "action", so unpack the "action=... | key=value" string instead.
    legacy = fields.pop("message", "")
    if "action" not in fields:
        for key, value in parse_action(legacy).items():
            fields.setdefault(key, value)

    return conversation_id, fields


def parse_action(message: str) -> dict:
    """Legacy: parse 'action=create_incident | details=...' into a dict.

    Splits on '|' then on the FIRST '=' so a value may itself contain '='. NOTE: if a
    free-text value (e.g. details) contains a literal '|', it will be truncated at that
    pipe -- which is exactly why the flat JSON payload above is the preferred form.
    """
    fields: dict = {}
    for part in (message or "").split("|"):
        part = part.strip()
        if not part or "=" not in part:
            continue
        key, value = part.split("=", 1)
        fields[key.strip()] = value.strip()
    return fields


#==============================================ServiceNow client===================================
# The Entra ID token is valid for ~1h. Cache it per worker and refresh 5 minutes early so a
# burst of invocations does not re-authenticate on every call.
_token_lock = threading.Lock()
_token_cache = {"value": "", "expires_at": 0.0}


def get_token() -> str:
    """Return a cached Entra ID access token, fetching a new one when it is close to expiry."""
    if _token_cache["value"] and time.time() < _token_cache["expires_at"]:
        return _token_cache["value"]
    with _token_lock:
        if _token_cache["value"] and time.time() < _token_cache["expires_at"]:
            return _token_cache["value"]
        response = requests.post(
            TOKEN_URL,
            data={
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "scope": SCOPE,
                "grant_type": "client_credentials",
            },
            timeout=HTTP_TIMEOUT,
        )
        response.raise_for_status()
        payload = response.json()
        _token_cache["value"] = payload["access_token"]
        _token_cache["expires_at"] = time.time() + int(payload.get("expires_in", 3600)) - 300
        return _token_cache["value"]


def sn_call(method: str, query: str = "", body: dict = None) -> dict:
    """Call the incident endpoint and return its 'result' object.

    The record to act on is always selected by `query` (a ServiceNow encoded query passed
    as ?sysparm_query=...) -- NOT by identifiers in the body, which this API ignores.
    Raises ServiceNowError when the wrapper reports hasError.
    """
    headers = {"Authorization": f"Bearer {get_token()}", "Accept": "application/json"}
    if API_KEY:
        headers["x-Gateway-APIKey"] = API_KEY

    response = requests.request(
        method,
        INCIDENT_URL,
        headers=headers,
        params={"sysparm_query": query} if query else None,
        json=body,
        timeout=HTTP_TIMEOUT,
    )
    response.raise_for_status()
    result = (response.json() or {}).get("result") or {}
    if result.get("hasError"):
        raise ServiceNowError(result.get("errorMsg") or "ServiceNow rejected the request.")
    return result


def find_incident_number(fields: dict, conversation_id: str) -> str:
    """Resolve which incident this action applies to.

    An explicit incident_id always wins; otherwise we look up the one incident stamped
    with u_inbound_key = conversation_id at create time.
    """
    number = fields.get("incident_id", "").strip()
    if number:
        return number
    if not conversation_id:
        raise ServiceNowError("No incident_id supplied and no conversation_id to look one up by.")
    found = sn_call("GET", query=f"u_inbound_key={conversation_id}").get("number", "")
    if not found:
        raise ServiceNowError(f"No incident found for conversation_id '{conversation_id}'.")
    return found


#==============================================Actions=============================================
def create_incident(fields: dict, conversation_id: str) -> dict:
    """POST a new incident. description / u_ticket_source / u_customer_ci are mandatory."""
    details = fields.get("details", "").strip()
    if not details:
        raise ServiceNowError("'details' is required to create an incident.")
    issue_type = fields.get("issue_type", "")

    # short_description is the one-line summary shown in ServiceNow lists, so prefer a real
    # summary over the bare issue_type; the full text always goes to description.
    summary = fields.get("short_description") or (f"{issue_type}: {details}" if issue_type else details)
    body = {
        "description": details,
        "short_description": summary[:160],
        "u_ticket_source": TICKET_SOURCE,
        "u_customer_ci": CUSTOMER_CI,
    }
    # u_inbound_key persists only on create -- this is what ties the incident to the
    # conversation so later actions can find it without an incident_id.
    if conversation_id:
        body["u_inbound_key"] = conversation_id
    for source, target in (("caller_id", "caller_id"), ("impact", "impact"), ("urgency", "urgency")):
        if fields.get(source):
            body[target] = fields[source]

    result = sn_call("POST", body=body)
    number = result.get("number", "")
    return {
        "incident_id": number,
        "issue_type": issue_type,
        "state": result.get("state", ""),
        "message": f"Incident {number} created in ServiceNow.",
    }


def update_incident(fields: dict, conversation_id: str) -> dict:
    """PUT a work note onto the incident. Note that this API silently ignores attempts to
    change short_description or u_inbound_key, so we only send journal fields."""
    note = fields.get("note", "").strip()
    if not note:
        raise ServiceNowError("'note' is required to update an incident.")
    number = find_incident_number(fields, conversation_id)

    body = {"work_notes": note}
    if fields.get("comments"):
        body["comments"] = fields["comments"]
    sn_call("PUT", query=f"number={number}", body=body)
    return {
        "incident_id": number,
        "note": note,
        "message": f"Work note added to incident {number}.",
    }


def resolve_incident(fields: dict, conversation_id: str) -> dict:
    """PUT the incident to Resolved. The data policy makes cmdb_ci, u_resolution_method,
    u_what_was_done and comments mandatory for this transition, so all four are always sent.

    The API echoes the state it ATTEMPTED to set rather than what was stored, so we read the
    record back and report the state ServiceNow actually persisted.
    """
    number = find_incident_number(fields, conversation_id)
    note = fields.get("note", "").strip() or "Resolved by the ServiceNow agent."

    sn_call(
        "PUT",
        query=f"number={number}",
        body={
            "state": RESOLVED_STATE,
            "close_code": CLOSE_CODE,
            "close_notes": note,
            "comments": note,
            "u_what_was_done": fields.get("what_was_done") or note,
            "u_resolution_method": RESOLUTION_METHOD,
            "cmdb_ci": fields.get("cmdb_ci") or CUSTOMER_CI,
        },
    )

    state = sn_call("GET", query=f"number={number}").get("state", "")
    if state == RESOLVED_STATE:
        message = f"Incident {number} resolved."
    else:
        # Observed in dev: the resolve is accepted but a ServiceNow-side rule reverts it.
        message = (
            f"ServiceNow accepted the resolve for {number} but the incident is still in "
            f"state '{state}'. It may need an assignment group or further mandatory fields."
        )
        logging.warning("Resolve did not persist for %s (state=%s)", number, state)
    return {"incident_id": number, "state": state, "message": message}


def get_incident(fields: dict, conversation_id: str) -> dict:
    """GET the incident. This endpoint only ever returns number / sys_id / state /
    short_description -- sysparm_fields and sysparm_display_value are ignored."""
    number = find_incident_number(fields, conversation_id)
    result = sn_call("GET", query=f"number={number}")
    return {
        "incident_id": result.get("number", number),
        "state": result.get("state", ""),
        "short_description": result.get("short_description", ""),
        "message": f"Incident {number} retrieved.",
    }


HANDLERS = {
    "create_incident": create_incident,
    "update_incident": update_incident,
    "resolve": resolve_incident,
    "get_incident": get_incident,
}


#==============================================Azure Function Entry================================
def main(req: func.HttpRequest) -> func.HttpResponse:
    """HTTP entry point: parse the action and run it against the real ServiceNow API."""
    conversation_id, fields = extract_request(req)
    action = fields.get("action", "")
    logging.info("ServiceNow: conversation_id=%s action=%s fields=%s", conversation_id, action, fields)

    handler = HANDLERS.get(action)
    if handler is None:
        return json_response(
            {
                "message": f"Unsupported action '{action}'.",
                "supported_actions": list(SUPPORTED_ACTIONS),
            },
            status=400,
        )

    try:
        return json_response(handler(fields, conversation_id))
    except ServiceNowError as exc:
        # A business/validation failure from ServiceNow -- the caller can act on this.
        logging.warning("ServiceNow rejected action=%s: %s", action, exc)
        return json_response({"message": str(exc), "action": action}, status=400)
    except requests.RequestException as exc:
        logging.exception("ServiceNow transport error")
        return json_response(
            {"message": "Could not reach ServiceNow.", "details": str(exc)}, status=502
        )
    except Exception as exc:  # final safety net
        logging.exception("ServiceNow agent error")
        return json_response(
            {"message": "ServiceNow agent error.", "details": str(exc)}, status=500
        )