#####################################################################################
## LOCAL TESTING ONLY -- not part of the deployed Function.                          #
##                                                                                  #
## Serves the Function's main() over plain HTTP so you can hit it from Postman       #
## without Azure Functions Core Tools, an Azure login, or a Function App.            #
##                                                                                  #
##   python local_server.py                                                          #
##   -> POST http://localhost:7071/api/ServiceNowAgent                                #
##                                                                                  #
## Azure never imports this file, so leaving it in the folder is harmless.           #
#####################################################################################

import importlib.util
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

# Corporate TLS interception on this laptop breaks certifi, so requests would fail with
# CERTIFICATE_VERIFY_FAILED. truststore makes Python use the WINDOWS certificate store,
# which already trusts the corporate root CA. Azure does not need this -- which is why it
# lives in this local harness and not in __init__.py.
try:
    import truststore

    truststore.inject_into_ssl()
    print("[local] truststore active (using Windows certificate store)")
except ImportError:
    print("[local] truststore NOT installed -- if you get CERTIFICATE_VERIFY_FAILED, run:")
    print("[local]   pip install truststore")

import azure.functions as func

# Load __init__.py under a normal module name (importing a module literally called
# "__init__" is legal but confusing, and breaks if the cwd changes).
_spec = importlib.util.spec_from_file_location(
    "sn_function", os.path.join(os.path.dirname(os.path.abspath(__file__)), "__init__.py")
)
sn_function = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(sn_function)

PORT = int(os.getenv("LOCAL_PORT", "7071"))


class Handler(BaseHTTPRequestHandler):
    def _run(self, method: str) -> None:
        parsed = urlparse(self.path)
        # parse_qs gives {key: [v1, v2]}; the Functions runtime exposes a flat dict.
        params = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else b""

        request = func.HttpRequest(
            method=method,
            url=f"http://localhost:{PORT}{self.path}",
            headers=dict(self.headers),
            params=params,
            route_params={},
            body=body,
        )

        try:
            response = sn_function.main(request)
            status = response.status_code
            payload = response.get_body()
        except Exception as exc:  # a crash in main() would otherwise just drop the connection
            status = 500
            payload = json.dumps({"message": "Unhandled error in main()", "details": str(exc)}).encode()

        # flush=True so you see each request as it happens instead of at shutdown.
        print(f"[local] {method} {self.path} -> {status} {payload.decode('utf-8', 'replace')[:400]}",
              flush=True)
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_POST(self):  # noqa: N802 - name required by BaseHTTPRequestHandler
        self._run("POST")

    def do_GET(self):  # noqa: N802
        self._run("GET")

    def log_message(self, *args):  # silence the default per-request stderr logging
        pass


if __name__ == "__main__":
    print(f"[local] ServiceNowAgent listening on http://localhost:{PORT}")
    print(f"[local] POST http://localhost:{PORT}/api/ServiceNowAgent")
    try:
        ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
    except KeyboardInterrupt:
        print("\n[local] stopped")
        sys.exit(0)
