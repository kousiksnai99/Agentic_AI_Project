# ServiceNow Agent (Azure Function)

HTTP-triggered Azure Function that fronts the Teva **ServiceNow ticketing API**. It takes a
flat JSON action from the orchestrator, calls the real ServiceNow gateway, and returns the
incident id. Ticket numbers come from ServiceNow — they are never generated locally.

| File | Purpose |
|---|---|
| `__init__.py` | The Function. All ServiceNow logic lives here. |
| `function.json` | HTTP trigger binding (`authLevel: function`, POST + GET). |
| `requirements.txt` | Dependencies. See the note inside about the repo-root file. |
| `local_server.py` | **Local testing only.** Serves `main()` over plain HTTP for Postman. Azure never imports it. |

---

## 1. Actions

Send `POST` with `Content-Type: application/json`. Every action needs `conversation_id`
and `action`; the rest are per-action.

| Action | Request fields | Response fields |
|---|---|---|
| `create_incident` | `issue_type`, `details`, *(optional)* `short_description`, `caller_id`, `impact`, `urgency` | `incident_id`, `issue_type`, `state`, `message` |
| `update_incident` | `note`, *(optional)* `incident_id`, `comments` | `incident_id`, `note`, `message` |
| `resolve` | *(optional)* `incident_id`, `note`, `what_was_done` | `incident_id`, `state`, `message` |
| `get_incident` | *(optional)* `incident_id` | `incident_id`, `state`, `short_description`, `message` |

**`incident_id` is optional on everything except the first create.** On create, the Function
stamps `u_inbound_key = conversation_id` in ServiceNow; later actions look the incident up by
that key. This is what makes *one incident per conversation* work with no server-side cache,
so it survives restarts and scale-out.

The legacy pipe form is still accepted:
`{"conversation_id": "c1", "message": "action=update_incident | note=called again"}`

Query params also work for quick browser checks:
`GET /api/ServiceNowAgent?conversation_id=c1&action=get_incident`

### Status codes
- `200` — action succeeded.
- `400` — ServiceNow rejected it, a required field was missing, or the action is unknown. Body has `message`.
- `502` — could not reach ServiceNow (network/TLS).
- `500` — unexpected error.

`create_interaction` / `close_interaction` were **removed** — the gateway exposes no
`interaction` table, so they cannot be backed by a real record. They return `400`.

---

## 2. Local setup (venv), step by step

Run these one after another in PowerShell:

```powershell
# 1. go to the function folder
cd c:\Users\2113456\Downloads\ServiceNowAgent

# 2. create the virtual environment
python -m venv .venv

# 3. activate it  (prompt changes to "(.venv)")
.\.venv\Scripts\Activate.ps1

# 4. upgrade pip
python -m pip install --upgrade pip

# 5. install dependencies -- the long timeout matters on the corporate network
pip install -r requirements.txt --timeout 60 --retries 5

# 6. confirm
python -c "import azure.functions, requests, truststore; print('OK')"
```

Then start the local server:

```powershell
python local_server.py
```

Expected output:

```
[local] truststore active (using Windows certificate store)
[local] ServiceNowAgent listening on http://localhost:7071
[local] POST http://localhost:7071/api/ServiceNowAgent
```

Stop it with `Ctrl+C`. To leave the venv later, run `deactivate`.

### Troubleshooting

| Problem | Fix |
|---|---|
| `Activate.ps1 cannot be loaded ... running scripts is disabled` | `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` then activate again. (Or use `cmd` and `.venv\Scripts\activate.bat`.) |
| `ReadTimeoutError ... pypi.org` during install | Corporate network is slow, not broken. Re-run step 5 — the `--timeout 60 --retries 5` flags usually get it through. |
| `SSLError: CERTIFICATE_VERIFY_FAILED` | `truststore` is missing. `pip install truststore`. This is why plain scripts fail locally but `local_server.py` works. |
| `address already in use` on 7071 | A server is already running. `Get-Process python \| Stop-Process -Force`, or set a different port: `$env:LOCAL_PORT=7072`. |
| Postman can't reach `localhost` | Use Postman **desktop**, not web. Postman web needs the Desktop Agent. |

Add `.venv/` to `.gitignore` so it is never committed.

---

## 3. Testing from Postman

- Method: **POST**
- URL: `http://localhost:7071/api/ServiceNowAgent`
- Header: `Content-Type: application/json`
- Auth: **None** (the function key is not enforced locally)
- Body → **raw** → **JSON**

Run these four in order, reusing the same `conversation_id`:

```json
{"conversation_id":"conv-test-1","action":"create_incident","issue_type":"email","details":"Outlook will not start after the latest update."}
```
```json
{"conversation_id":"conv-test-1","action":"update_incident","note":"User called again for an update."}
```
```json
{"conversation_id":"conv-test-1","action":"get_incident"}
```
```json
{"conversation_id":"conv-test-1","action":"resolve","note":"Reinstalled the Outlook profile."}
```

The first returns a real number such as `INC09485444`. Open it in
`tevadev.service-now.com` to confirm the description, work notes and Ticket Source landed —
that is the proof the write reached ServiceNow rather than the API merely returning `200`.

Use a **fresh `conversation_id` for each test run**. Calling `create_incident` twice with the
same id creates two incidents, and lookups then return the older one.

Every request is also logged live in the terminal running `local_server.py`.

---

## 4. Configuration

Every value reads from an environment variable first, falling back to the client-provided dev
default in `__init__.py`, so local testing needs no setup.

| Env var | Purpose |
|---|---|
| `SN_TENANT_ID`, `SN_CLIENT_ID`, `SN_CLIENT_SECRET`, `SN_SCOPE` | Entra ID client-credentials auth |
| `SN_BASE_URL`, `SN_RESOURCE_PATH` | Gateway base URL and the resource token scoping this caller to the incident table |
| `SN_API_KEY` | `x-Gateway-APIKey`. Optional — the Bearer token alone is sufficient. Set to `""` to stop sending it. |
| `SN_TICKET_SOURCE`, `SN_CUSTOMER_CI` | Mandatory-on-create field values |
| `SN_RESOLUTION_METHOD`, `SN_CLOSE_CODE`, `SN_RESOLVED_STATE` | Resolve field values |

**Auth flow:** Entra ID `client_credentials` → Bearer token, valid ~1h, cached per worker and
refreshed 5 minutes before expiry.

---

## 5. API contract (reverse-engineered)

The client supplied no schema — every request body in the Postman collection is empty — so
this was derived from the live dev instance. Non-obvious behaviour worth knowing:

- Only `incident` is usable. `sys_user` ignores all query params and always returns the same
  record; `sc_task` and `submitCatalog` reject this `resourcePath`; there is no `interaction` table.
- Responses are wrapped: `{"result": {"hasError": false, ...}}`. **`hasError` can be `true` on an HTTP `200`**, so the status code alone means nothing.
- `GET` needs a `sysparm_query` and returns **one record as an object**, not a list — and only ever `number`, `sys_id`, `state`, `short_description`. `sysparm_fields` and `sysparm_display_value` are ignored.
- **Create requires exactly three fields:** `description`, `u_ticket_source`, `u_customer_ci`.
  `contact_type` is *not* Ticket Source and `cmdb_ci` is *not* Customer CI — both are silently ignored.
  Mandatory-field errors come back **in Portuguese**.
- **On `PUT`, the record is identified by `?sysparm_query=number=INC…`, not by the body.**
  Identifiers in the body are silently discarded.
- `PUT` also silently drops `short_description` and `u_inbound_key` while still reporting success.
- `u_inbound_key` persists **only on create**. That is why it is the correlation key.
- `PATCH` returns `405`. Use `PUT`.
- Resolving requires `cmdb_ci`, `u_resolution_method`, `u_what_was_done` and `comments`.
- `u_ticket_source`, `close_code` and `u_resolution_method` accept **any** string — no validation.

---

## 6. Known issues / open with the client

1. **`resolve` does not persist.** The `PUT` returns `hasError: false` and echoes `state: "6"`,
   but re-reading shows the incident back at state `1`/`2` — a ServiceNow-side rule reverts it.
   Likely needs an assignment group, or resolution by an authorised user. The Function
   re-reads the record and reports the true state rather than claiming success.
   *The API echoes the state it attempted, not what was stored — never trust the PUT response.*
2. **`SN_CUSTOMER_CI` is a placeholder.** Mandatory on create; the current value was taken from
   an unrelated `sc_task` record just to make creates work. The business must confirm the correct CI.
3. **No user lookup.** `sys_user` is effectively a stub, so `caller_id` cannot be resolved from
   a name or email. Needs its own `resourcePath`.
4. Valid choice lists for `u_ticket_source`, `close_code` and `u_resolution_method` are unknown.
5. `create_incident` is **not idempotent** — it does not check whether the conversation already
   has an incident.

---

## 7. Before deploying

- [ ] Add `requests` to the **repo-root** `requirements.txt`. Without it the function dies on `import requests`.
- [ ] Move the client secret to App Settings as `SN_CLIENT_SECRET` and delete the literal default.
      It is currently hardcoded and **will trip Azure DevOps secret scanning (SEC101)** on push.
- [ ] Confirm the real `SN_CUSTOMER_CI` with the business.
- [ ] Settle the `resolve` behaviour with the client — it does not work today.
- [ ] Check the Function App's Python version. Local dev here is 3.13; Azure Functions may not
      support that yet, so the App must be on a supported runtime (3.11 / 3.12).
- [ ] The deployed endpoint uses `authLevel: function`, so callers need `?code=<function key>`.
